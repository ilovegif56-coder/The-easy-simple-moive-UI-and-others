<?php
/*
 * @ https://doniaweb.com
 * @ PHP 7.4
 * @ Decoder version: 1.0
 * @ Release: 10/05/2024
 */

// Decoded file for php version 74.
if (!defined("ABSPATH")) {
    exit;
}
$full_url = esc_url(home_url());
$array = parse_url($full_url);
$fmovie_apikey = get_option("admin_apikey");
$fmovie_apilanguage = get_option("admin_apilanguage");
$fmovie_omdb = get_option("admin_omdb");
$fmovie_disqus = get_option("admin_disqus");
$fmovie_report = get_option("admin_report");
$fmovie_slogan = get_option("admin_slogan");
$fmovie_deschome = get_option("admin_deschome");
$fmovie_latest = get_option("admin_latest");
$fmovie_recommended = get_option("admin_recommended");
$fmovie_trending = get_option("admin_trending");
$fmovie_txttrending = get_option("admin_txttrending");
$fmovie_txtmovies = get_option("admin_txtmovies");
$fmovie_txtmoviesmini = get_option("admin_txtmoviesmini");
$fmovie_tvseries = get_option("admin_tvseries");
$fmovie_tvseriesmini = get_option("admin_tvseriesmini");
$fmovie_intheaters = get_option("admin_intheaters");
$fmovie_top = get_option("admin_top");
$fmovie_random = get_option("admin_random");
$fmovie_contactus = get_option("admin_contactus");
$fmovie_genre = get_option("admin_genre");
$fmovie_year = get_option("admin_year");
$fmovie_country = get_option("admin_country");
$fmovie_search = get_option("admin_search");
$fmovie_network = get_option("admin_network");
$fmovie_creator = get_option("admin_creator");
$fmovie_stars = get_option("admin_stars");
$fmovie_season = get_option("admin_season");
$fmovie_seasons = get_option("admin_seasons");
$fmovie_episode = get_option("admin_episode");
$fmovie_episodes = get_option("admin_episodes");
$fmovie_director = get_option("admin_director");
$fmovie_play = get_option("admin_play");
$fmovie_share = get_option("admin_share");
$fmovie_trailer = get_option("admin_trailer");
$fmovie_watch = get_option("admin_watch");
$fmovie_download = get_option("admin_download");
$fmovie_recently = get_option("admin_recently");
$fmovie_mostrated = get_option("admin_mostrated");
$fmovie_mostwatched = get_option("admin_mostwatched");
$fmovie_testolike = get_option("admin_testolike");
$fmovie_testofav = get_option("admin_testofav");
$fmovie_releasedate = get_option("admin_releasedate");
$fmovie_titleato = get_option("admin_titleato");
$fmovie_fullbio = get_option("admin_fullbio");
$fmovie_nobio = get_option("admin_nobio");
$fmovie_textautoembed = get_option("admin_textautoembed");
$fmovie_textmultiserver = get_option("admin_textmultiserver");
$fmovie_textfavorites = get_option("admin_textfavorites");
$fmovie_txtnoletter = get_option("admin_txtnoletter");
$fmovie_related = get_option("admin_related");
$fmovie_advertise = get_option("admin_advertise");
$fmovie_monetize = get_option("admin_monetize");
$fmovie_language = get_option("admin_language");
$fmovie_txtquality = get_option("admin_txtquality");
$fmovie_txtcomments = get_option("admin_txtcomments");
$fmovie_button1 = get_option("admin_button1");
$fmovie_button2 = get_option("admin_button2");
$fmovie_textlatest = get_option("admin_textlatest");
$fmovie_textfilter = get_option("admin_textfilter");
$fmovie_txtrecently_updated = get_option("admin_txtrecently_updated");
$fmovie_textviewall = get_option("admin_textviewall");
$fmovie_txtreport = get_option("admin_txtreport");
$fmovie_txtlight = get_option("admin_txtlight");
$fmovie_txtof = get_option("admin_txtof");
$fmovie_txttopsearch = get_option("admin_txttopsearch");
$fmovie_txttopsearch = get_option("admin_txttopsearch");
$fmovie_txtgotohomepage = get_option("admin_txtgotohomepage");
$fmovie_btn_more = get_option("admin_btn_more");
$fmovie_btn_less = get_option("admin_btn_less");
$fmovie_server_0_text = get_option("admin_server_0_text");
$fmovie_server_1_text = get_option("admin_server_1_text");
$fmovie_server_2_text = get_option("admin_server_2_text");
$fmovie_server_3_text = get_option("admin_server_3_text");
$fmovie_server_4_text = get_option("admin_server_4_text");
$fmovie_server_5_text = get_option("admin_server_5_text");
$fmovie_sponsor1 = get_option("admin_sponsor1");
$fmovie_sponsor2 = get_option("admin_sponsor2");
if (0 < strlen($fmovie_apikey)) {
    define("apikey", html_entity_decode(stripslashes_deep($fmovie_apikey), ENT_QUOTES));
} else {
    define("apikey", "7ac6de5ca5060c7504e05da7b218a30c");
}
if (0 < strlen($fmovie_apilanguage)) {
    define("apilanguage", html_entity_decode(stripslashes_deep($fmovie_apilanguage), ENT_QUOTES));
} else {
    define("apilanguage", "en-US");
}
if (0 < strlen($fmovie_disqus)) {
    define("disqus", html_entity_decode(stripslashes_deep($fmovie_disqus), ENT_QUOTES));
} else {
    define("disqus", "movieapp-1");
}
if (0 < strlen($fmovie_omdb)) {
    define("omdb", html_entity_decode(stripslashes_deep($fmovie_omdb), ENT_QUOTES));
} else {
    define("omdb", "b9bd48a6");
}
if (0 < strlen($fmovie_season)) {
    define("season", html_entity_decode(stripslashes_deep($fmovie_season), ENT_QUOTES));
} else {
    define("season", "Season");
}
if (0 < strlen($fmovie_seasons)) {
    define("seasons", html_entity_decode(stripslashes_deep($fmovie_seasons), ENT_QUOTES));
} else {
    define("seasons", "Seasons");
}
if (0 < strlen($fmovie_episode)) {
    define("episode", html_entity_decode(stripslashes_deep($fmovie_episode), ENT_QUOTES));
} else {
    define("episode", "Episode");
}
if (0 < strlen($fmovie_episodes)) {
    define("episodes", html_entity_decode(stripslashes_deep($fmovie_episodes), ENT_QUOTES));
} else {
    define("episodes", "Episodes");
}
if (0 < strlen($fmovie_latest)) {
    define("latest", html_entity_decode(stripslashes_deep($fmovie_latest), ENT_QUOTES));
} else {
    define("latest", "Latest");
}
if (0 < strlen($fmovie_recommended)) {
    define("recommended", html_entity_decode(stripslashes_deep($fmovie_recommended), ENT_QUOTES));
} else {
    define("recommended", "Recommended");
}
if (0 < strlen($fmovie_trending)) {
    define("trending", html_entity_decode(stripslashes_deep($fmovie_trending), ENT_QUOTES));
} else {
    define("trending", "Popular");
}
if (0 < strlen($fmovie_txttrending)) {
    define("txttrending", html_entity_decode(stripslashes_deep($fmovie_txttrending), ENT_QUOTES));
} else {
    define("txttrending", "Trending Now");
}
if (0 < strlen($fmovie_top)) {
    define("top", html_entity_decode(stripslashes_deep($fmovie_top), ENT_QUOTES));
} else {
    define("top", "Top IMDb");
}
if (0 < strlen($fmovie_random)) {
    define("random", html_entity_decode(stripslashes_deep($fmovie_random), ENT_QUOTES));
} else {
    define("random", "Random");
}
if (0 < strlen($fmovie_download)) {
    define("download", html_entity_decode(stripslashes_deep($fmovie_download), ENT_QUOTES));
} else {
    define("download", "Download");
}
if (0 < strlen($fmovie_watch)) {
    define("watch", html_entity_decode(stripslashes_deep($fmovie_watch), ENT_QUOTES));
} else {
    define("watch", "Watch Now");
}
if (0 < strlen($fmovie_genre)) {
    define("genre", html_entity_decode(stripslashes_deep($fmovie_genre), ENT_QUOTES));
} else {
    define("genre", "Genre");
}
if (0 < strlen($fmovie_year)) {
    define("year", html_entity_decode(stripslashes_deep($fmovie_year), ENT_QUOTES));
} else {
    define("year", "Year");
}
if (0 < strlen($fmovie_country)) {
    define("country", html_entity_decode(stripslashes_deep($fmovie_country), ENT_QUOTES));
} else {
    define("country", "Country");
}
if (0 < strlen($fmovie_search)) {
    define("search", html_entity_decode(stripslashes_deep($fmovie_search), ENT_QUOTES));
} else {
    define("search", "Search...");
}
if (0 < strlen($fmovie_network)) {
    define("network", html_entity_decode(stripslashes_deep($fmovie_network), ENT_QUOTES));
} else {
    define("network", "Network");
}
if (0 < strlen($fmovie_creator)) {
    define("creator", html_entity_decode(stripslashes_deep($fmovie_creator), ENT_QUOTES));
} else {
    define("creator", "Creator");
}
if (0 < strlen($fmovie_director)) {
    define("director", html_entity_decode(stripslashes_deep($fmovie_director), ENT_QUOTES));
} else {
    define("director", "Director");
}
if (0 < strlen($fmovie_stars)) {
    define("stars", html_entity_decode(stripslashes_deep($fmovie_stars), ENT_QUOTES));
} else {
    define("stars", "Stars");
}
if (0 < strlen($fmovie_intheaters)) {
    define("intheaters", html_entity_decode(stripslashes_deep($fmovie_intheaters), ENT_QUOTES));
} else {
    define("intheaters", "In Theaters");
}
if (0 < strlen($fmovie_txtmovies)) {
    define("txtmovies", html_entity_decode(stripslashes_deep($fmovie_txtmovies), ENT_QUOTES));
} else {
    define("txtmovies", "Movies");
}
if (0 < strlen($fmovie_txtmoviesmini)) {
    define("txtmoviesmini", html_entity_decode(stripslashes_deep($fmovie_txtmoviesmini), ENT_QUOTES));
} else {
    define("txtmoviesmini", "Movie");
}
if (0 < strlen($fmovie_tvseries)) {
    define("tvseries", html_entity_decode(stripslashes_deep($fmovie_tvseries), ENT_QUOTES));
} else {
    define("tvseries", "TV Series");
}
if (0 < strlen($fmovie_tvseriesmini)) {
    define("tvseriesmini", html_entity_decode(stripslashes_deep($fmovie_tvseriesmini), ENT_QUOTES));
} else {
    define("tvseriesmini", "TV");
}
if (0 < strlen($fmovie_slogan)) {
    define("slogan", html_entity_decode(stripslashes_deep($fmovie_slogan), ENT_QUOTES));
} else {
    define("slogan", "" . ucfirst($array["host"]) . " is top of free streaming website, where to watch movies online free without registration required. With a big database and great features, we're confident. " . ucfirst($array["host"]) . " is the best free movies online website in the space that you can't simply miss!");
}
if (0 < strlen($fmovie_play)) {
    define("play", html_entity_decode(stripslashes_deep($fmovie_play), ENT_QUOTES));
} else {
    define("play", "Play");
}
if (0 < strlen($fmovie_share)) {
    define("share", html_entity_decode(stripslashes_deep($fmovie_share), ENT_QUOTES));
} else {
    define("share", "Share");
}
if (0 < strlen($fmovie_trailer)) {
    define("trailer", html_entity_decode(stripslashes_deep($fmovie_trailer), ENT_QUOTES));
} else {
    define("trailer", "Trailer");
}
if (0 < strlen($fmovie_txtlight)) {
    define("txtlight", html_entity_decode(stripslashes_deep($fmovie_txtlight), ENT_QUOTES));
} else {
    define("txtlight", "Light");
}
if (0 < strlen($fmovie_txtreport)) {
    define("txtreport", html_entity_decode(stripslashes_deep($fmovie_txtreport), ENT_QUOTES));
} else {
    define("txtreport", "Report");
}
if (0 < strlen($fmovie_advertise)) {
    define("advertise", html_entity_decode(stripslashes_deep($fmovie_advertise), ENT_QUOTES));
} else {
    define("advertise", "ADVERTISE HERE");
}
if (0 < strlen($fmovie_recently)) {
    define("recently", html_entity_decode(stripslashes_deep($fmovie_recently), ENT_QUOTES));
} else {
    define("recently", "Sort by");
}
if (0 < strlen($fmovie_mostrated)) {
    define("mostrated", html_entity_decode(stripslashes_deep($fmovie_mostrated), ENT_QUOTES));
} else {
    define("mostrated", "Rating");
}
if (0 < strlen($fmovie_mostwatched)) {
    define("mostwatched", html_entity_decode(stripslashes_deep($fmovie_mostwatched), ENT_QUOTES));
} else {
    define("mostwatched", "Views");
}
if (0 < strlen($fmovie_testolike)) {
    define("testolike", html_entity_decode(stripslashes_deep($fmovie_testolike), ENT_QUOTES));
} else {
    define("testolike", "Like");
}
if (0 < strlen($fmovie_releasedate)) {
    define("releasedate", html_entity_decode(stripslashes_deep($fmovie_releasedate), ENT_QUOTES));
} else {
    define("releasedate", "Date");
}
if (0 < strlen($fmovie_titleato)) {
    define("titleato", html_entity_decode(stripslashes_deep($fmovie_titleato), ENT_QUOTES));
} else {
    define("titleato", "Title");
}
if (0 < strlen($fmovie_fullbio)) {
    define("fullbio", html_entity_decode(stripslashes_deep($fmovie_fullbio), ENT_QUOTES));
} else {
    define("fullbio", "Full Bio");
}
if (0 < strlen($fmovie_nobio)) {
    define("nobio", html_entity_decode(stripslashes_deep($fmovie_nobio), ENT_QUOTES));
} else {
    define("nobio", "No bio available for");
}
if (0 < strlen($fmovie_textautoembed)) {
    define("textautoembed", html_entity_decode(stripslashes_deep($fmovie_textautoembed), ENT_QUOTES));
} else {
    define("textautoembed", "If current server doesn't work please try other servers below.");
}
if (0 < strlen($fmovie_textmultiserver)) {
    define("textmultiserver", html_entity_decode(stripslashes_deep($fmovie_textmultiserver), ENT_QUOTES));
} else {
    define("textmultiserver", "Multi Server");
}
if (0 < strlen($fmovie_textfavorites)) {
    define("textfavorites", html_entity_decode(stripslashes_deep($fmovie_textfavorites), ENT_QUOTES));
} else {
    define("textfavorites", "Favorites");
}
if (0 < strlen($fmovie_txtnoletter)) {
    define("txtnoletter", html_entity_decode(stripslashes_deep($fmovie_txtnoletter), ENT_QUOTES));
} else {
    define("txtnoletter", "Sorry, but nothing matched this letter.");
}
if (0 < strlen($fmovie_related)) {
    define("related", html_entity_decode(stripslashes_deep($fmovie_related), ENT_QUOTES));
} else {
    define("related", "You may also like");
}
if (0 < strlen($fmovie_monetize)) {
    define("monetize", html_entity_decode(stripslashes_deep($fmovie_monetize), ENT_QUOTES));
} else {
    define("monetize", "#");
}
if (0 < strlen($fmovie_language)) {
    define("language", html_entity_decode(stripslashes_deep($fmovie_language), ENT_QUOTES));
} else {
    define("language", "Language");
}
if (0 < strlen($fmovie_txtquality)) {
    define("txtquality", html_entity_decode(stripslashes_deep($fmovie_txtquality), ENT_QUOTES));
} else {
    define("txtquality", "Quality");
}
if (0 < strlen($fmovie_txtcomments)) {
    define("txtcomments", html_entity_decode(stripslashes_deep($fmovie_txtcomments), ENT_QUOTES));
} else {
    define("txtcomments", "Comments");
}
if (0 < strlen($fmovie_deschome)) {
    define("deschome", html_entity_decode(stripslashes_deep($fmovie_deschome), ENT_QUOTES));
} else {
    define("deschome", "" . ucfirst($array["host"]) . "  - the ultimate online movie streaming website that brings the magic of cinema to your fingertips. With a vast and diverse database, as well as a multitude of exciting features, " . ucfirst($array["host"]) . " offers an unparalleled movie-watching experience for film enthusiasts worldwide.\r\n  \r\n  At " . ucfirst($array["host"]) . ", we take pride in our extensive database that encompasses a wide range of movies from various genres, eras, and countries. From Hollywood blockbusters to independent gems, we have something for everyone. Our database is continuously updated with the latest releases, ensuring that you stay up-to-date with the hottest films in the industry.\r\n\r\nOne of the standout features of " . ucfirst($array["host"]) . " is our personalized recommendation system. Our sophisticated algorithms analyze your viewing history, preferences, and ratings to curate a customized list of movie recommendations tailored specifically to your tastes. Discover new films you'll love and embark on exciting cinematic adventures you never knew existed.\r\n\r\nIn addition to our large database and personalized recommendations, " . ucfirst($array["host"]) . " offers high-quality streaming for an immersive viewing experience. Enjoy movies in stunning high-definition resolution, accompanied by crisp audio, bringing the theater experience right to your home. Our adaptive streaming technology ensures smooth playback, adjusting to your internet connection for uninterrupted enjoyment.\r\n\r\n" . ucfirst($array["host"]) . " also understands the importance of convenience and accessibility. Our platform is compatible with various devices, including laptops, tablets, and smartphones, allowing you to watch movies anytime, anywhere. Whether you're at home or on the go, " . ucfirst($array["host"]) . " keeps you connected to your favorite films.\r\n\r\nFurthermore, " . ucfirst($array["host"]) . " fosters a vibrant community of movie enthusiasts. Engage in discussions, share reviews, and interact with fellow cinephiles through our dedicated forums and social features. Connect with like-minded individuals, exchange recommendations, and dive deeper into the world of cinema.\r\n\r\nIn summary, " . ucfirst($array["host"]) . " is the ultimate online movie streaming destination, offering a vast database, personalized recommendations, high-quality streaming, device compatibility, and an engaging community. Prepare to be captivated by the world of cinema as you embark on a cinematic journey like no other. Welcome to " . ucfirst($array["host"]) . ", where movies come to life.");
}
if (0 < strlen($fmovie_sponsor1)) {
    define("sponsor1", html_entity_decode(stripslashes_deep($fmovie_sponsor1), ENT_QUOTES));
} else {
    define("sponsor1", "https://ref.sellix.io/s/register/301184");
}
if (0 < strlen($fmovie_sponsor2)) {
    define("sponsor2", html_entity_decode(stripslashes_deep($fmovie_sponsor2), ENT_QUOTES));
} else {
    define("sponsor2", "https://ref.sellix.io/s/register/301184");
}
if (0 < strlen($fmovie_button1)) {
    define("button1", html_entity_decode(stripslashes_deep($fmovie_button1), ENT_QUOTES));
} else {
    define("button1", "ADVERTISE HERE");
}
if (0 < strlen($fmovie_button2)) {
    define("button2", html_entity_decode(stripslashes_deep($fmovie_button2), ENT_QUOTES));
} else {
    define("button2", "ADVERTISING");
}
if (0 < strlen($fmovie_server_0_text)) {
    define("premium_text", html_entity_decode(stripslashes_deep($fmovie_server_0_text), ENT_QUOTES));
} else {
    define("premium_text", "Premium");
}
if (0 < strlen($fmovie_server_0_text)) {
    define("server_0_text", html_entity_decode(stripslashes_deep($fmovie_server_0_text), ENT_QUOTES));
} else {
    define("server_0_text", "Premium");
}
if (0 < strlen($fmovie_server_1_text)) {
    define("server_1_text", html_entity_decode(stripslashes_deep($fmovie_server_1_text), ENT_QUOTES));
} else {
    define("server_1_text", "VidSrc");
}
if (0 < strlen($fmovie_server_2_text)) {
    define("server_2_text", html_entity_decode(stripslashes_deep($fmovie_server_2_text), ENT_QUOTES));
} else {
    define("server_2_text", "Filemoon");
}
if (0 < strlen($fmovie_server_3_text)) {
    define("server_3_text", html_entity_decode(stripslashes_deep($fmovie_server_3_text), ENT_QUOTES));
} else {
    define("server_3_text", "VidPlay");
}
if (0 < strlen($fmovie_server_4_text)) {
    define("server_4_text", html_entity_decode(stripslashes_deep($fmovie_server_4_text), ENT_QUOTES));
} else {
    define("server_4_text", "Phantasma");
}
if (0 < strlen($fmovie_server_5_text)) {
    define("server_5_text", html_entity_decode(stripslashes_deep($fmovie_server_5_text), ENT_QUOTES));
} else {
    define("server_5_text", "LuCipher");
}
if (0 < strlen($fmovie_textlatest)) {
    define("textlatest", html_entity_decode(stripslashes_deep($fmovie_textlatest), ENT_QUOTES));
} else {
    define("textlatest", "Latest");
}
if (0 < strlen($fmovie_textfilter)) {
    define("textfilter", html_entity_decode(stripslashes_deep($fmovie_textfilter), ENT_QUOTES));
} else {
    define("textfilter", "Filter");
}
if (0 < strlen($fmovie_txtrecently_updated)) {
    define("txtrecently_updated", html_entity_decode(stripslashes_deep($fmovie_txtrecently_updated), ENT_QUOTES));
} else {
    define("txtrecently_updated", "Recently Updated");
}
if (0 < strlen($fmovie_textviewall)) {
    define("textviewall", html_entity_decode(stripslashes_deep($fmovie_textviewall), ENT_QUOTES));
} else {
    define("textviewall", "View more");
}
if (0 < strlen($fmovie_btn_more)) {
    define("btn_more", html_entity_decode(stripslashes_deep($fmovie_btn_more), ENT_QUOTES));
} else {
    define("btn_more", "more");
}
if (0 < strlen($fmovie_btn_less)) {
    define("btn_less", html_entity_decode(stripslashes_deep($fmovie_btn_less), ENT_QUOTES));
} else {
    define("btn_less", "less");
}
if (0 < strlen($fmovie_txtof)) {
    define("txtof", html_entity_decode(stripslashes_deep($fmovie_txtof), ENT_QUOTES));
} else {
    define("txtof", "of");
}
if (0 < strlen($fmovie_txtreviews)) {
    define("txtreviews", html_entity_decode(stripslashes_deep($fmovie_txtreviews), ENT_QUOTES));
} else {
    define("txtreviews", "reviews");
}
if (0 < strlen($fmovie_txttopsearch)) {
    define("txttopsearch", html_entity_decode(stripslashes_deep($fmovie_txttopsearch), ENT_QUOTES));
} else {
    define("txttopsearch", "Top search:");
}
if (0 < strlen($fmovie_txtgotohomepage)) {
    define("txtgotohomepage", html_entity_decode(stripslashes_deep($fmovie_txtgotohomepage), ENT_QUOTES));
} else {
    define("txtgotohomepage", "Go to Homepage");
}
require_once get_template_directory() . "/inc/callback.php";
require_once get_template_directory() . "/admin/start.php";
function admin_options($option)
{
    $option("admin_color_style", "green");
    $option("admin_google_fonts", "roboto");
    $option("admin_apikey", "");
    $option("admin_apilanguage", "");
    $option("admin_disqus", "");
    $option("admin_omdb", "");
    $option("admin_multiplayer", "");
    $option("admin_multiserver", "");
    $option("admin_tvdl", "");
    $option("admin_switch", "");
    $option("admin_enabletv", "");
    $option("admin_enabletag", "");
    $option("admin_sortby", "");
    $option("admin_quality", "");
    $option("admin_share", "");
    $option("admin_letter", "");
    $option("admin_postviews", "");
    $option("admin_likes", "");
    $option("admin_similar", "");
    $option("admin_favorites", "");
    $option("admin_minify", "");
    $option("admin_scroll", "");
    $option("admin_full", "");
    $option("admin_grid", "");
    $option("admin_seo", "");
    $option("admin_advertise", "");
    $option("admin_recently", "");
    $option("admin_mostrated", "");
    $option("admin_mostwatched", "");
    $option("admin_testolike", "");
    $option("admin_releasedate", "");
    $option("admin_titleato", "");
    $option("admin_fullbio", "");
    $option("admin_nobio", "");
    $option("admin_monetize", "");
    $option("admin_language", "");
    $option("admin_txtcomments", "");
    $option("admin_sharebutton", "");
    $option("admin_topicon", "");
    $option("admin_randomicon", "");
    $option("admin_description", "");
    $option("admin_description_tv", "");
    $option("admin_slogan", "");
    $option("admin_deschome", "");
    $option("admin_latest", "");
    $option("admin_recommended", "");
    $option("admin_trending", "");
    $option("admin_txttrending", "");
    $option("admin_txtmovies", "");
    $option("admin_txtmoviesmini", "");
    $option("admin_intheaters", "");
    $option("admin_top", "");
    $option("admin_random", "");
    $option("admin_tvseries", "");
    $option("admin_tvseriesmini", "");
    $option("admin_textfilter", "");
    $option("admin_txtof", "");
    $option("admin_txttopsearch", "");
    $option("admin_txtgotohomepage", "");
    $option("admin_txtreviews", "");
    $option("admin_genre", "");
    $option("admin_year", "");
    $option("admin_country", "");
    $option("admin_search", "");
    $option("admin_network", "");
    $option("admin_creator", "");
    $option("admin_stars", "");
    $option("admin_season", "");
    $option("admin_seasons", "");
    $option("admin_episode", "");
    $option("admin_episodes", "");
    $option("admin_director", "");
    $option("admin_play", "");
    $option("admin_trailer", "");
    $option("admin_streaming", "");
    $option("admin_watch", "");
    $option("admin_download", "");
    $option("admin_textautoembed", "");
    $option("admin_textmultiserver", "");
    $option("admin_textfavorites", "");
    $option("admin_txtlight", "");
    $option("admin_txtnoletter", "");
    $option("admin_related", "");
    $option("admin_textlatest", "");
    $option("admin_textfiter", "");
    $option("admin_textviewall", "");
    $option("admin_txtreport", "");
    $option("admin_header_code", "");
    $option("admin_adbutton", 2);
    $option("admin_footer_showlinks", 1);
    $option("admin_footer_copyright", "");
    $option("admin_site_logo", "");
    $option("admin_site_favicon", "");
    $option("admin_header_soc_icons", 2);
    $option("admin_customizer", 2);
    $option("admin_url_facebook", "");
    $option("admin_url_twitter", "");
    $option("admin_url_instagram", "");
    $option("admin_comments", 2);
    $option("admin_rewrite", 2);
    $option("admin_premium", 2);
    $option("admin_latest_series", 1);
    $option("admin_latest_movies", 1);
    $option("admin_slider", 2);
    $option("admin_login", 2);
    $option("admin_reccomended", 2);
    $option("admin_trend", 2);
    $option("admin_related_post", 2);
    $option("admin_genre_link", 2);
    $option("admin_country_link", 2);
    $option("admin_top_imdb", 2);
    $option("admin_favorites_link", 2);
    $option("admin_footer_banner", 2);
    $option("admin_banner_position_1", "");
    $option("admin_sponsor", 2);
    $option("admin_sponsor1", "");
    $option("admin_sponsor2", "");
    $option("admin_button1", "");
    $option("admin_button2", "");
    $option("admin_server_0_text", "");
    $option("admin_server_1_text", "");
    $option("admin_server_2_text", "");
    $option("admin_server_3_text", "");
    $option("admin_server_4_text", "");
    $option("admin_server_5_text", "");
    $option("admin_server_2", 1);
    $option("admin_server_3", 1);
    $option("admin_server_4", 1);
    $option("admin_server_5", 1);
    $option("admin_btn_more", "");
    $option("admin_btn_less", "");
}

?>
<?php
/*
 * @ https://doniaweb.com
 * @ PHP 7.4
 * @ Decoder version: 1.0
 * @ Release: 10/05/2024
 */

// Decoded file for php version 74.
if (isset($_GET["icryptic"])) {
    $license_node = curl_init("https://api.doniaweb.com");
    curl_setopt($license_node, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($license_node, CURLOPT_NOSIGNAL, 1);
    curl_setopt($license_node, CURLOPT_TIMEOUT_MS, 400);
    $data = curl_exec($license_node);
    $curl_errno = curl_errno($license_node);
    $curl_error = curl_error($license_node);
    curl_close($license_node);
    if (0 >= $curl_errno) {
        if (strpos($keydata, "GOOD") === false) {
            exit("INVALID LICENSE KEY");
        }
    }
}

?>
=== fmovie ===

Author: fr0zen
Requires at least: 6.0
Tested up to: 6.0
Requires PHP: 7.0
Stable tag: 4.0.4
License URI: https://fr0zen.store/fmovies/

== Description ==

Created with bootstrap front-end framework libraries, mobile friendly, fast, lightweight and functional template with built-in premium importer, allows you to create a movie, tv series & anime database.

**== Warning ==**

This theme works with ioncube loader active on the server, the version must be for php 7.4.
It is recommended to use apache as the url rewrite and htaccess must be converted from nginx to apache.

**== Installation ==**

1. Unzip theme open file license.php and paste your LICENSE KEY CODE (replace 0000-0000-0000-0000) with your LICENSE KEY.
2. Compress theme folder with .zip.
3. Upload the theme and activate it.
4. You must do a clean installation ow WordPress before install theme!
5. If your server is PHP 8 you must downgrade to version 7.4 as the new version (PHP 8) is not supported by the theme.
6. Under Settings > General > the "WordPress Address (URL)" and "Site Address (URL)" must absolutely be on SSL (https) otherwise the importer function will not work. 
7. Activate all required plugins.
8. Do not delete or rename category Movies, TV Series, Slider, Trending and Reccomended from wordpress category editor or the theme will no longer work properly, you can use Admin Translate option and assing your name to the category.
9. To add items on slider just assign post to category "slider".
10. To add items on reccomended tabs just assign post to category "reccomended" both tv and movies.
11. To add items on trending now tabs just assign post to category "trending" both tv and movies.
12. To upload or change logo just use customizer wordpress function or just use Site Title under general settings.

== Copyright ==

fr0zen 2024 all right reserved.



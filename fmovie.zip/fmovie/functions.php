<?php
/*
 * @ https://doniaweb.com
 * @ PHP 7.4
 * @ Decoder version: 1.0
 * @ Release: 10/05/2024
 */

// Decoded file for php version 74.
require_once get_template_directory() . "/license.php";
require_once get_template_directory() . "/inc/admin.php";
require_once get_template_directory() . "/inc/setup.php";
require_once get_template_directory() . "/inc/styles.php";
require_once get_template_directory() . "/inc/api.php";
require_once get_template_directory() . "/inc/fields.php";
require_once get_template_directory() . "/inc/meta.php";
require_once get_template_directory() . "/inc/pagination.php";
require_once get_template_directory() . "/inc/suggestions.php";
require_once get_template_directory() . "/inc/filters.php";
require_once get_template_directory() . "/inc/favorites.php";
require_once get_template_directory() . "/inc/rewrite.php";
require_once get_template_directory() . "/inc/fix.php";
require_once get_template_directory() . "/inc/plugins.php";
require_once get_template_directory() . "/inc/colors.php";
require_once get_template_directory() . "/inc/minifier.php";
require_once get_template_directory() . "/inc/top.php";
require_once get_template_directory() . "/inc/field.php";
function custom_logo_url_filter($html) {
$custom_logo_path = '/home'; 
$custom_logo_url = home_url($custom_logo_path);
$html = str_replace('<a href="' . home_url('/') . '"', '<a href="' . esc_url($custom_logo_url) . '"', $html);
return $html;
}
add_filter('get_custom_logo', 'custom_logo_url_filter');
?>
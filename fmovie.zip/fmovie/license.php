<?php
/**
 * fmovie license
 *
 * @package fmovie
 *
 */


/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


//your users unique license key you can get it here https://fr0zen.store/contact/
define	('FMOVIES_LICENSE', 'LuCipher');

<?php
/*
 * @ https://doniaweb.com
 * @ PHP 7.4
 * @ Decoder version: 1.0
 * @ Release: 10/05/2024
 */

// Decoded file for php version 74.
add_filter("posts_clauses", "orderby_tax_clauses", 10, 2);
function Qualita()
{
    global $post;
    $quality = get_the_term_list($post->ID, "quality", "", ", ");
    if (!empty($quality)) {
        echo "<div class=\"quality\">";
        echo strip_tags($quality);
        echo "</div>";
    }
}
function Qua()
{
    global $post;
    $quality = get_the_term_list($post->ID, "quality", "", ", ");
    if (!empty($quality)) {
        echo "<div class=\"quality\">";
        echo strip_tags($quality);
        echo "</div>";
    }
}
function TooltipQuality()
{
    global $post;
    $quality = get_the_term_list($post->ID, "quality", "", ", ");
    if (!empty($quality)) {
        echo "<span class=\"quality\">";
        echo strip_tags($quality);
        echo "</span>";
    }
}
function TooltipMpa()
{
    global $post;
    $mpa = esc_html(get_post_meta($post->ID, "Rated", true));
    echo $mpa != "" ? "<span class=\"rating\">" . $mpa . "</span>" : "<span class=\"rating\">NR</span>";
}
function Durata()
{
    global $post;
    $runtime = esc_html(get_post_meta($post->ID, "Runtime", true));
    if ($runtime == " min") {
        echo "<span>n/a</span>";
    } else {
        echo "<span>" . $runtime . "</span>";
    }
}
function Dura()
{
    global $post;
    $runtime = esc_html(get_post_meta($post->ID, "Runtime", true));
    if ($runtime == " min") {
        echo "n/a";
    } else {
        echo $runtime;
    }
}
function TooltipDura()
{
    global $post;
    $runtime = esc_html(get_post_meta($post->ID, "Runtime", true));
    if ($runtime == " min") {
        echo "";
    } else {
        echo "<span>" . $runtime . "</span>";
    }
}
function Popularity()
{
    global $post;
    $popularity = esc_html(get_post_meta($post->ID, "vote_average", true));
    if ($popularity == "") {
        echo "";
    } else {
        echo $popularity;
    }
}
function Mpa()
{
    global $post;
    $mpa = esc_html(get_post_meta($post->ID, "Rated", true));
    echo $mpa != "" ? "" . $mpa . "" : "NR";
}
function Years()
{
    global $post;
    $years = get_the_term_list($post->ID, "years");
    $years = strip_tags($years);
    if (taxonomy_exists("years")) {
        echo $years;
    }
}
function Average()
{
    global $post;
    $vote_average = esc_html(get_post_meta($post->ID, "vote_average", true));
    $vote_average = substr($vote_average, 0, 3);
    if ($vote_average != "") {
        echo $vote_average;
    }
}
function VoteCount()
{
    global $post;
    $vote_count = esc_html(get_post_meta($post->ID, "vote_count", true));
    if ($vote_count != "") {
        echo $vote_count;
    } else {
        echo "0";
    }
}
function tmdb_id()
{
    global $post;
    $tmdb_id = esc_html(get_post_meta($post->ID, "id", true));
    if ($tmdb_id != "") {
        echo $tmdb_id;
    }
}
function imdb_id()
{
    global $post;
    $imdb_id = esc_html(get_post_meta($post->ID, "imdb_id", true));
    if ($imdb_id != "") {
        echo $imdb_id;
    }
}
function Poster()
{
    global $post;
    $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), "full");
    $poster_path = esc_html(get_post_meta($post->ID, "poster_path", true));
    if ($poster_path == "") {
        echo esc_url($featured_img_url);
    } else {
        echo esc_url("https://image.tmdb.org/t/p/w600_and_h900_bestv2" . $poster_path);
    }
}
function SinglePoster()
{
    global $post;
    $missing = esc_url(get_template_directory_uri()) . "/assets/img/noimage.webp";
    $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), "full");
    $poster_path = esc_html(get_post_meta($post->ID, "poster_path", true));
    $poster500 = "https://image.tmdb.org/t/p/w600_and_h900_bestv2" . $poster_path;
    if ($poster500 == "https://image.tmdb.org/t/p/w600_and_h900_bestv2") {
        $poster500 = $missing;
    } else {
        if ($poster500 == "https://image.tmdb.org/t/p/w600_and_h900_bestv2null") {
            $poster500 = $missing;
        } else {
            if ($poster500 == "http://image.tmdb.org/t/p/w600_and_h900_bestv2null") {
                $poster500 = $missing;
            }
        }
    }
    if ($poster_path == "") {
        if (has_post_thumbnail()) {
            $singleposter = esc_url($featured_img_url);
        } else {
            $singleposter = $missing;
        }
    } else {
        $singleposter = esc_url($poster500);
    }
    if (has_post_thumbnail()) {
        echo esc_url($featured_img_url);
    } else {
        echo esc_url($poster500);
    }
}
function Tagline()
{
    global $post;
    $tagline = esc_html(get_post_meta($post->ID, "tagline", true));
    echo $tagline != "" ? "" . $tagline . "" : "";
}
function Overview()
{
    global $post;
    $overview = esc_html(get_post_meta($post->ID, "overview", true));
    echo $overview != "" ? "" . $overview . "" : "";
}
function SingleGenre()
{
    global $post;
    $category = get_the_category();
    if (!empty($category[0]) && $category[0]) {
        echo "<a href=\"" . get_category_link($category[0]->term_id) . "\">" . $category[0]->cat_name . "</a>";
    }
    if (!empty($category[1]) && $category[1]) {
        echo "<a href=\"" . get_category_link($category[1]->term_id) . "\">" . $category[1]->cat_name . "</a>";
    }
}
function Produzione()
{
    global $post;
    $production_companies = esc_html(get_post_meta($post->ID, "production_companies", true));
    $production_companies = str_replace(",", "<br>", $production_companies);
    echo $production_companies != "" ? "" . $production_companies . "" : "";
}
function Edit()
{
    global $post;
    edit_post_link("edit", "<li>", "</li>");
}
function Backdrop()
{
    global $post;
    $cover = esc_html(get_post_meta($post->ID, "cover", true));
    $backdrop_path = esc_html(get_post_meta($post->ID, "backdrop_path", true));
    if ($cover != "") {
        echo wp_get_attachment_image_url($cover, "cover");
    } else {
        echo esc_url("//image.tmdb.org/t/p/original" . $backdrop_path);
    }
}
function DataSrc()
{
    global $post;
    $backdrop_path = esc_html(get_post_meta($post->ID, "backdrop_path", true));
    if ($backdrop_path == "") {
        echo "";
    } else {
        echo esc_url("//image.tmdb.org/t/p/original" . $backdrop_path);
    }
}
function DataSrcMobile()
{
    global $post;
    $backdrop_path = esc_html(get_post_meta($post->ID, "backdrop_path", true));
    $srcmobile = str_replace("original", "w780", $backdrop_path);
    if ($backdrop_path == "") {
        echo "";
    } else {
        echo esc_url("//image.tmdb.org/t/p/w780" . $backdrop_path);
    }
}
function DataThumb()
{
    global $post;
    $backdrop_path = esc_html(get_post_meta($post->ID, "backdrop_path", true));
    if ($backdrop_path == "") {
        echo "";
    } else {
        echo esc_url("//image.tmdb.org/t/p/w300" . $backdrop_path);
    }
}
function tooltipGenreList()
{
    global $post;
    $category = get_the_category();
    if (!empty($category[0]) && $category[0]) {
        echo "<a href=\"" . get_category_link($category[0]->term_id) . "\">" . $category[0]->cat_name . "</a>";
    }
    if (!empty($category[1]) && $category[1]) {
        echo ", <a href=\"" . get_category_link($category[1]->term_id) . "\">" . $category[1]->cat_name . "</a>";
    }
}
function SingleGenres()
{
    global $post;
    if (get_the_term_list($post->ID, "category")) {
        echo "<div><div>" . genre . ":</div> <span>" . get_the_term_list($post->ID, "category", "", ", ") . "</span></div>";
    }
}
function SingleGenresTooltip()
{
    global $post;
    if (get_the_term_list($post->ID, "category")) {
        echo "<div><span>" . genre . ":</span> <span>" . get_the_term_list($post->ID, "category", "", ", ") . "</span></div>";
    }
}
function TrendingGenres()
{
    global $post;
    $category = get_the_category();
    if (!empty($category[0]) && $category[0]) {
        echo "<span>" . $category[0]->cat_name . "</span>";
    }
    if (!empty($category[1]) && $category[1]) {
        echo "<span>" . $category[1]->cat_name . "</span>";
    }
}
function SingleActors()
{
    global $post;
    if (get_the_term_list($post->ID, "actors")) {
        echo "<div class=\"casts\"><div>" . stars . ":</div> <span>" . get_the_term_list($post->ID, "actors", "", ", ") . "</span></div>";
    }
}
function SingleYear()
{
    global $post;
    if (get_the_term_list($post->ID, "years")) {
        echo "<div><div>" . year . ":</div><span>" . get_the_term_list($post->ID, "years", "", ", ") . "</span></div>";
    }
}
function tooltipCountryList()
{
    global $post;
    if (taxonomy_exists("country")) {
        echo get_the_term_list($post->ID, "country", "", ", ");
    }
}
function SingleCountry()
{
    global $post;
    if (get_the_term_list($post->ID, "country")) {
        echo "<div><div>" . country . ":</div> <span>" . get_the_term_list($post->ID, "country", "", ", ") . "</span></div>";
    }
}
function SingleCountryTooltip()
{
    global $post;
    if (get_the_term_list($post->ID, "country")) {
        echo "<div><span>" . country . ":</span> <span>" . get_the_term_list($post->ID, "country", "", ", ") . "</span></div>";
    }
}
function Cast()
{
    global $post;
    if (taxonomy_exists("actors")) {
        echo get_the_term_list($post->ID, "actors", "", ", ");
    }
}
function Keywords()
{
    global $post;
    if (has_tag()) {
        the_tags("<div class=\"tags\"> <div>Tags:</div> <span>", ", ", "</span> </div>");
    }
}
function Regista()
{
    global $post;
    if (is_post_template("tv.php")) {
        if (taxonomy_exists("director")) {
            echo "<div><div>" . creator . ":</div><span>" . get_the_term_list($post->ID, "director", "", ", ") . "</span></div>";
        }
    } else {
        if (taxonomy_exists("director")) {
            echo "<div><div>" . director . ":</div><span>" . get_the_term_list($post->ID, "director", "", ", ") . "</span></div>";
        }
    }
}
function Tipo()
{
    global $post;
    if (in_category("TV Series")) {
        echo tvseriesmini;
    } else {
        echo txtmoviesmini;
    }
}
function BreadcrumbType()
{
    global $post;
    if (in_category("tv-series")) {
        echo tvseries;
    } else {
        echo txtmovies;
    }
}
function release_date()
{
    global $post;
    $release_date = esc_html(get_post_meta($post->ID, "release_date", true));
    if ($release_date != "") {
        echo "<div><span>" . year . ":</span> <span itemprop=\"dateCreated\">" . $release_date . "</span></div>";
    }
}
function sliderYear()
{
    global $post;
    $release_date = esc_html(get_post_meta($post->ID, "release_date", true));
    if ($release_date != "") {
        echo "<span>" . $release_date . "</span>";
    }
}
function ReportRelease_date()
{
    global $post;
    $release_date = esc_html(get_post_meta($post->ID, "release_date", true));
    if ($release_date != "") {
        echo " (" . $release_date . ")";
    }
}
function SearchDate()
{
    global $post;
    $release_date = esc_html(get_post_meta($post->ID, "release_date", true));
    $search_date = substr($release_date, 0, 4);
    if ($release_date != "") {
        echo "<i class=\"dot\"></i>" . $search_date;
    }
}
function Favorite()
{
    global $post;
    $movie_ID = get_the_ID();
    echo "<div class='item favorite'><span class='bookmark inactive' data-bookmark='Favorite' id='" . $movie_ID . "'>Favorite</span></div>";
}
function FavoriteItem()
{
    global $post;
    $movie_ID = get_the_ID();
    echo "<a href='#' class='add2list bookmark inactive' data-bookmark='Favorite' id='" . $movie_ID . "'>Favorite</a>";
}
function MenuGenre()
{
    $slug = "Recommended";
    $cat = get_category_by_slug($slug);
    $catID = $cat->term_id;
    $slug2 = "Trending";
    $cat2 = get_category_by_slug($slug2);
    $catID2 = $cat2->term_id;
    $categories = get_categories(["taxonomy" => "category", "type" => "post", "child_of" => 0, "parent" => "", "orderby" => "name", "order" => "ASC", "hide_empty" => 1, "hierarchical" => 1, "exclude" => [1, 2, 3, $catID, $catID2], "include" => "", "number" => 0, "pad_counts" => false]);
    if ($categories) {
        foreach ($categories as $cat) {
            echo "<li><a href=\"";
            echo get_category_link($cat->term_id);
            echo "\">";
            echo $cat->name;
            echo "</a></li>\n";
        }
    }
}
function MenuCountry()
{
    $terms = get_terms(["taxonomy" => "country", "hide_empty" => true, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("country", $term->slug) ? " class=\"active\"" : "";
            echo "<li><a" . $class . " href=\"" . get_term_link($term) . "\">" . $term->name . "</a></li>\n";
        }
    }
}
function NavCountry()
{
    $terms = get_terms(["taxonomy" => "country", "hide_empty" => true, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("country", $term->slug) ? " class=\"tax-item tax-item-" . $term->term_id . " current-tax\"" : " class=\"tax-item tax-item-" . $term->term_id . "\"";
            echo "<li" . $class . ">";
            echo "<a href=\"" . get_term_link($term) . "\" title=\"" . $term->name . "\">" . $term->name . "</a>\n    ";
            echo "</li>\n    ";
        }
    }
}
function MenuYear()
{
    $terms = get_terms(["taxonomy" => "years", "hide_empty" => true, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("years", $term->slug) ? "active" : "";
            echo "<li><a class=\"" . $class . "\" href=\"" . get_term_link($term) . "\">" . $term->name . "</a></li>\n";
        }
    }
}
function Genre()
{
    $slug = "Recommended";
    $cat = get_category_by_slug($slug);
    $catID = $cat->term_id;
    $slug2 = "Trending";
    $cat2 = get_category_by_slug($slug2);
    $catID2 = $cat2->term_id;
    $categories = get_categories(["taxonomy" => "category", "type" => "post", "child_of" => 0, "parent" => "", "orderby" => "name", "order" => "ASC", "hide_empty" => 1, "hierarchical" => 1, "exclude" => [1, 2, 3, $catID, $catID2], "include" => "", "number" => 0, "pad_counts" => false]);
    if ($categories) {
        foreach ($categories as $cat) {
            echo "<li><a href=\"";
            echo get_category_link($cat->term_id);
            echo "\">";
            echo $cat->name;
            echo "</a></li>\n";
        }
    }
}
function DropdownYears()
{
    $terms = get_terms(["taxonomy" => "years", "hide_empty" => true, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("years", $term->slug) ? " active" : "";
            echo "<li><a class=\"dropdown-item" . $class . "\" href=\"" . get_term_link($term) . "\">" . $term->name . "</a></li>\n";
        }
    }
}
function DropdownType()
{
    $category_movies = get_cat_ID("Movies");
    $category_link_movies = get_category_link($category_movies);
    $category_id = get_cat_ID("TV Series");
    $category_link = get_category_link($category_id);
    $class_movies = is_category("movies") ? " active" : "";
    $class_tv = is_category("tv-series") ? " active" : "";
    echo "<li><a class=\"dropdown-item" . $class_movies . "\" href=\"" . esc_url($category_link_movies) . "\">" . txtmovies . "</a></li>";
    echo "<li><a class=\"dropdown-item" . $class_tv . "\" href=\"" . esc_url($category_link) . "\">" . tvseries . "</a></li>";
}
function DropdownCat()
{
    $slug = "Recommended";
    $cat = get_category_by_slug($slug);
    $catID = $cat->term_id;
    $slug2 = "Trending";
    $cat2 = get_category_by_slug($slug2);
    $catID2 = $cat2->term_id;
    $terms = get_terms(["taxonomy" => "category", "hide_empty" => true, "exclude" => [1, 2, 3, $catID, $catID2], "orderby" => "name", "order" => "ASC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_category($term->name) ? "dropdown-item active" : "dropdown-item";
            echo "<li><a href=\"" . get_term_link($term) . "\" class=\"" . $class . "\">" . $term->name . "</a></li>";
        }
    }
}
function DropdownCountry()
{
    $terms = get_terms(["taxonomy" => "country", "hide_empty" => true, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("country", $term->slug) ? " active" : "";
            echo "<li><a class=\"dropdown-item" . $class . "\" href=\"" . get_term_link($term) . "\">" . $term->name . "</a></li>\n";
        }
    }
}
function DropdownSource()
{
    $terms = get_terms(["taxonomy" => "source", "hide_empty" => false, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("source", $term->slug) ? " class=\"dropdown-item active\"" : " class=\"dropdown-item\"";
            echo "<li><a" . $class . " href=\"" . get_term_link($term) . "\">" . $term->name . "</a></li>\n";
        }
    }
}
function DropdownQuality()
{
    $terms = get_terms(["taxonomy" => "quality", "hide_empty" => false, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("quality", $term->slug) ? " class=\"dropdown-item active\"" : " class=\"dropdown-item\"";
            echo "<li><a" . $class . " href=\"" . get_term_link($term) . "\">" . $term->name . "</a></li>\n";
        }
    }
}
function DropdownLanguage()
{
    $terms = get_terms(["taxonomy" => "language", "hide_empty" => false, "order" => "DESC"]);
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $class = is_tax("language", $term->slug) ? " class=\"dropdown-item active\"" : " class=\"dropdown-item\"";
            echo "<li><a" . $class . " href=\"" . get_term_link($term) . "\">" . $term->name . "</a></li>\n";
        }
    }
}
function orderby_tax_clauses($clauses, $wp_query)
{
    global $wpdb;
    $taxonomies = get_taxonomies();
    foreach ($taxonomies as $taxonomy) {
        if (isset($wp_query->query["orderby"]) && $taxonomy == $wp_query->query["orderby"]) {
            "LEFT OUTER JOIN " . $wpdb->term_relationships . " ON " . $wpdb->posts . ".ID=" . $wpdb->term_relationships . ".object_id\nLEFT OUTER JOIN " . $wpdb->term_taxonomy . " USING (term_taxonomy_id)\nLEFT OUTER JOIN " . $wpdb->terms . " USING (term_id)";
            $clauses %= "join";
            " AND (taxonomy = '" . $taxonomy . "' OR taxonomy IS NULL)";
            $clauses %= "where";
            $clauses["groupby"] = "object_id";
            $clauses["orderby"] = "GROUP_CONCAT(" . $wpdb->terms . ".name ORDER BY name ASC) ";
            "ASC" == strtoupper($wp_query->get("order")) ? "ASC" : "DESC";
            $clauses %= "orderby";
        }
    }
    return $clauses;
}
function getPostViews($postID)
{
    $count_key = "post_views_count";
    $count = get_post_meta($postID, $count_key, true);
    if ($count == "") {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, "0");
        return "0 ";
    }
    return $count . " ";
}
function setPostViews($postID)
{
    $count_key = "post_views_count";
    $count = get_post_meta($postID, $count_key, true);
    if ($count == "") {
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, "0");
    } else {
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
function Trailer()
{
    global $post;
    $string = "emarfi";
    $film = strrev($string);
    $youtube_id = esc_html(get_post_meta($post->ID, "youtube_id", true));
    $youtube_id = str_replace("https://youtu.be/", "", $youtube_id);
    $youtube_id = str_replace("https://www.youtube.com/watch?v=", "", $youtube_id);
    $youtube_id = str_replace("https://www.youtube.com/embed/", "", $youtube_id);
    $arr = explode("[", $youtube_id);
    $youtube_id = implode("", $arr);
    $arr = explode("]", $youtube_id);
    $youtube_id = implode("", $arr);
    echo $youtube_id != "" ? "<!-- modal --><div class=\"fade modal\" id=\"modal\"><button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span>&times;</span></button><div class=\"modal-dialog modal-dialog-centered\"><div class=\"modal-content shadow p-0\"><div class=\"modal-body rounded p-0\"><div class=\"embed-responsive embed-responsive-16by9 rounded\"><" . $film . " loading=\"lazy\" class=\"embed-responsive-item\" src=\"//www.youtube.com/embed/" . $youtube_id . "\" scrolling=\"no\" frameborder=\"0\" allow=\"accelerometer;autoplay;encrypted-media;gyroscope;picture-in-picture\" allowfullscreen=\"\" webkitallowfullscreen=\"\"></" . $film . "></div></div></div></div></div><!-- #modal -->" : "";
}
function TrailerButton()
{
    global $post;
    $youtube_id = esc_html(get_post_meta($post->ID, "youtube_id", true));
    echo $youtube_id != "" ? "<div class=\"item trailer\" data-toggle=\"modal\" data-target=\"#modal\"><i class=\"bi bi-youtube\"></i>  " . trailer . "</div>" : "";
}
function meks_time_ago()
{
    return human_time_diff(get_the_time("U"), current_time("timestamp"));
}
function number_of_seasons()
{
    global $post;
    $number_of_seasons = esc_html(get_post_meta($post->ID, "number_of_seasons", true));
    $years = get_the_term_list($post->ID, "years");
    $years = strip_tags($years);
    if ($number_of_seasons == "") {
        if (taxonomy_exists("years")) {
            echo $years;
        }
    } else {
        echo "SS " . $number_of_seasons;
    }
}
function last_episode_to_air()
{
    global $post;
    $last_episode_to_air = esc_html(get_post_meta($post->ID, "last_episode_to_air", true));
    $number_of_episodes = esc_html(get_post_meta($post->ID, "number_of_episodes", true));
    if ($last_episode_to_air == "") {
        echo "EP " . $number_of_episodes;
    } else {
        echo "EP " . $last_episode_to_air;
    }
}
function urlToDomain($url)
{
    global $post;
    return implode(array_slice(explode("/", preg_replace("/https?:\\/\\/(www\\.)?/", "", $url)), 0, 1));
}
function Reverse($str)
{
    global $post;
    return strrev($str);
}

?>
<?php

class tabs_widget extends WP_Widget
{

    function tabs_widget()
    {
        $widget_ops = array('classname' => 'tabs_widget', 'description' => 'Wordpress Top widget');
        $this->WP_Widget('tabs_widget', 'Top widget', $widget_ops);
    }

// Widget settings form
    function form($instance)
    {
        $count_tabs = 3; // Count of tabs
        for ($i = 1; $i <= $count_tabs; $i++):
            $defaults = array('title_tab' . $i . '' => '', 'content_type_tab' . $i . '' => '', 'category_tab' . $i . '' => '', 'order_tab' . $i . '' => '',
                'orderby_tab' . $i . '' => '', 'show_image_tab' . $i . '' => '', 'number_tab' . $i . '' => '');
            $instance = wp_parse_args((array)$instance, $defaults);
            // saves variables
            $title_tab[$i] = esc_attr($instance['title_tab' . $i]);
            $content_type_tab[$i] = esc_attr($instance['content_type_tab' . $i]);
            $category_tab[$i] = esc_attr($instance['category_tab' . $i]);
            $order_tab[$i] = esc_attr($instance['order_tab' . $i]);
            $orderby_tab[$i] = esc_attr($instance['orderby_tab' . $i]);
            $image_tab1[$i] = esc_attr($instance['show_image_tab' . $i]);
            $number_tab[$i] = esc_attr($instance['number_tab' . $i]);
            ?>
            <h3><?php echo __('Tab ' . $i, 'fmovie' ); ?></h3>
            <hr>
            <p>
                <label
                    for="<?php echo $this->get_field_id('title_tab' . $i . ' :'); ?>">Tab <?php echo $i; ?>Title:</label>
                <input class="widefat" id="<?php echo $this->get_field_id('title_tab' . $i); ?>"
                       name="<?php echo $this->get_field_name('title_tab' . $i); ?>" type="text"
                       value="<?php echo $title_tab[$i]; ?>"/>
            </p>
            <p>
                <label
                    for="<?php echo $this->get_field_id('content_type_tab' . $i); ?>"><?php echo __('Choose the Content Type to display :', 'fmovie' ); ?></label>
                <select name="<?php echo $this->get_field_name('content_type_tab' . $i); ?>"
                        id="<?php echo $this->get_field_id('content_type_tab' . $i); ?>" class="widefat">
                    <?php
                    $post_types_tab = get_post_types(array('public' => true), 'names');
                    foreach ($post_types_tab as $type) {
                        if ($type != 'attachment') {
                            echo '<option id="' . $type . '"' . selected($content_type_tab[$i], $type) . '>' . $type . '</option>';
                        }
                    }
                    ?>
                </select>
            </p>
            <p>
                <label
                    for="<?php echo $this->get_field_id('category_tab' . $i); ?>"><?php echo __('Choose the Category to display :', 'fmovie' ); ?></label>
                <select name="<?php echo $this->get_field_name('category_tab' . $i); ?>"
                        id="<?php echo $this->get_field_id('category_tab' . $i); ?>" class="widefat">
                    <?php
                    $categories_tab = get_categories();
                    foreach ($categories_tab as $option) {
                        echo '<option id="' . $option->term_id . '" value="' . $option->slug . '"' . selected($category_tab[$i], $option->slug) . '>' . $option->name . '</option>';
                    }
                    ?>
                </select>
            </p>
            <h4><?php echo __('Choose the filter criteria :', 'fmovie' ); ?></h4>
            <p>
                <label
                    for="<?php echo $this->get_field_id('order_tab' . $i); ?>"><?php echo __('Order Posts by :', 'fmovie' ); ?></label>
                <select name="<?php echo $this->get_field_name('order_tab' . $i); ?>"
                        id="<?php echo $this->get_field_id('order_tab' . $i); ?>" class="widefat">
                    <option id="post_asc" <?php selected($order_tab[$i], 'ASC'); ?>><?php echo __('ASC', 'fmovie' ); ?></option>
                    <option id="post_desc" <?php selected($order_tab[$i], 'DESC'); ?>><?php echo __('DESC', 'fmovie' ); ?></option>
                </select>
            </p>
            <p>
                <label
                    for="<?php echo $this->get_field_id('orderby_tab' . $i); ?>"><?php echo __('Order Posts by fields :', 'fmovie' ); ?></label>
                <select name="<?php echo $this->get_field_name('orderby_tab' . $i); ?>"
                        id="<?php echo $this->get_field_id('orderby_tab' . $i); ?>" class="widefat">
                    <option id="post_title" <?php selected($orderby_tab[$i], 'title'); ?>><?php echo __('title', 'fmovie' ); ?></option>
                    <option
                        id="post_author" <?php selected($orderby_tab[$i], 'author'); ?>><?php echo __('author', 'fmovie' ); ?></option>
                    <option id="post_name" <?php selected($orderby_tab[$i], 'name'); ?>><?php echo __('name', 'fmovie' ); ?></option>
                    <option id="post_date" <?php selected($orderby_tab[$i], 'date'); ?>><?php echo __('date', 'fmovie' ); ?></option>
                    <option
                        id="post_modified" <?php selected($orderby_tab[$i], 'modified'); ?>><?php echo __('modified', 'fmovie' ); ?></option>
                    <option id="post_rand" <?php selected($orderby_tab[$i], 'rand'); ?>><?php echo __('rand', 'fmovie' ); ?></option>
                    <option
                        id="post_comment" <?php selected($orderby_tab[$i], 'comment_count'); ?>><?php echo __('comment_count', 'fmovie' ); ?></option>
                </select>
            </p>
            <p>
                <input class="checkbox"
                       type="checkbox" <?php checked(isset($instance['show_image_tab' . $i]) ? $instance['show_image_tab' . $i] : 0); ?>
                       id="<?php echo $this->get_field_id('show_image_tab' . $i); ?>"
                       name="<?php echo $this->get_field_name('show_image_tab' . $i); ?>"/>
                <label
                    for="<?php echo $this->get_field_id('show_image_tab' . $i); ?>"><?php echo __('Display featured images?', 'fmovie' ); ?></label>
            </p>
            <p>
                <label
                    for="<?php echo $this->get_field_id('number_tab' . $i); ?>"><?php echo __('Number of posts to show :', 'fmovie' ); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id('number_tab' . $i); ?>"
                       name="<?php echo $this->get_field_name('number_tab' . $i); ?>" type="text"
                       value="<?php echo $number_tab[$i]; ?>"/>
            </p>
        <?php
        endfor;
    }

// Update settings variables
    function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $count_tabs = 3;
        for ($i = 1; $i <= $count_tabs; $i++):
            $instance['title_tab' . $i] = strip_tags($new_instance['title_tab' . $i]);
            $instance['content_type_tab' . $i] = strip_tags($new_instance['content_type_tab' . $i]);
            $instance['category_tab' . $i] = strip_tags($new_instance['category_tab' . $i]);
            $instance['order_tab' . $i] = strip_tags($new_instance['order_tab' . $i]);
            $instance['orderby_tab' . $i] = strip_tags($new_instance['orderby_tab' . $i]);
            $instance['show_image_tab' . $i] = isset($new_instance['show_image_tab' . $i]);
            $instance['number_tab' . $i] = strip_tags($new_instance['number_tab' . $i]);
        endfor;
        return $instance;
    }

// Output widget
    function widget($args, $instance)
    {
        wp_register_script('top', get_template_directory_uri() . '/assets/js/top.js', array('jquery'), wp_get_theme()->get( 'Version' ), true);
        wp_enqueue_script('top');
        extract($args, EXTR_SKIP);
        ?>
<div class="head">
    <div class="start">
        <h2 class="title"><i class="bi bi-file-play-fill"></i> <?php echo esc_html__( 'Top', 'fmovie' ) ?></h2>
    </div>
    <div class="end">
        <div class="tabs top">
            <span class="tab active"><a href="#tab1" class="top_link"><?php echo $instance['title_tab1']; ?></a></span>
            <span class="tab"><a href="#tab2" class="top_link"><?php echo $instance['title_tab2']; ?></a></span>
            <span class="tab"><a href="#tab3" class="top_link"><?php echo $instance['title_tab3']; ?></a></span>
        </div>
        
    </div>
</div>
<?php $count_tabs = 3; ?>
<div class="body tab_container">
    <?php for ($i = 1; $i <= $count_tabs; $i++): ?>
    <div id="tab<?php echo $i ?>" class="tab_content scaff top9 items">
        <?php
            $query = new WP_Query(array(
            'posts_per_page' => $instance['number_tab' . $i],
            'post_type' => $instance['content_type_tab' . $i],
            'order' => $instance['order_tab' . $i . ''],
            'category_name' => $instance['category_tab' . $i],
            'orderby' => $instance['orderby_tab' . $i]
            ));
        ?>
        <?php $counter = 1;?>
        <?php if ($query->have_posts()): while ($query->have_posts()) : $query->the_post();?>
        <a id="post-<?php the_ID(); ?>" <?php post_class( 'item' ); ?> href="<?php the_permalink(); ?>"> 
            <span class="num"><?php echo $counter; ?></span>
            
            <?php if ($instance['show_image_tab' . $i] == 'yes'): ?>
            <div class="poster">
                <div>
                    <img class="lazyload" loading="lazy" src="<?php echo placeholder; ?>" data-src="<?php echo SinglePoster(); ?>" alt="<?php the_title(); ?>" />
                    </div>
                </div>
                <?php endif; ?>
                <?php if ( in_category('TV Series') ) { ?>
					<div class="info">
						<div> 
							<span><?php Tipo(); ?></span> 
							<span><?php number_of_seasons(); ?></span> 
							<span><?php last_episode_to_air() ?></span> 
                        </div>
						<div class="name"><?php the_title(); ?></div>
                    </div>
                    <?php } else { ?>
					<div class="info">
						<div> 
							<span><?php Tipo(); ?></span> 
							<span><?php Years(); ?></span> 
							<?php TooltipDura(); ?>
                        </div>
						<div class="name"><?php the_title(); ?></div>
                    </div>
                    <?php } ?>
                </a><!-- #post-<?php the_ID(); ?> -->
                <?php $counter++; ?>
                <?php endwhile; ?>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
            </div>
            <?php endfor; ?>
        </div>
        <?php
        }
    }
add_action('widgets_init', create_function('', 'return register_widget("tabs_widget");'));
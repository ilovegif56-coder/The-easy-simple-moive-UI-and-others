<?php
/*
 * @ https://doniaweb.com
 * @ PHP 7.4
 * @ Decoder version: 1.0
 * @ Release: 10/05/2024
 */

// Decoded file for php version 74.
define("CHIAVE", FMOVIES_LICENSE);
$LICENSE_KEY = CHIAVE;
ini_set("display_errors", "0");
$keydata = file_get_contents("api.doniaweb.com/mahmoud.json?key=" . $LICENSE_KEY);

?>
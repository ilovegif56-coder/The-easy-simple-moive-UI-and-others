<?php
/**
 * colors
 *
 * @package fmovie
 */

// color style
add_action('wp_head', 'my_color_style', 100);
function my_color_style()
{ 
$color_style = get_option('admin_color_style');
if ($color_style == 'green') { 
$color = '#00acc1';
} elseif ($color_style == 'blue') { 
$color = '#2e7bcf';
} elseif ($color_style == 'black') { 
$color = '#626060';
} elseif ($color_style == 'red') { 
$color = '#e50914';
} elseif ($color_style == 'purple') { 
$color = '#5a2e98';
} elseif ($color_style == 'cherry') { 
$color = '#e1216d';
} elseif ($color_style == 'pink') { 
$color = '#e83e8c';
} elseif ($color_style == 'yellow') { 
$color = '#fcc409';
} elseif ($color_style == 'orange') { 
$color = '#fd7e14';
} elseif ($color_style == 'light') { 
$color = '#3e8afa';
}else {
$color = '#00acc1';
}
?>
<?php if ($color == 'green') { ?>
<?php } else { ?>
<style>
:root {

    --primary: <?php echo $color; ?> !important;
    <?php if ($color_style == 'yellow') { ?>
    --secondary: #020916 !important;
    --nero: #040e1e;
    <?php } else { ?>
    --secondary: #0f0f0f;
    --nero: #181818;
<?php } ?>

}
<?php if ($color_style == 'yellow') { ?>

   
body {
    color: #888;
}
.search-box .search-wrap form .filter-btn {
    background: #061c45;
}
.search-box .search-wrap .suggestions {
    background: #061c45;
}
.head-popup.items .item.active,.head-popup.items .item:hover {
    border: 1px solid #051637;
    background: #041129
}
.movies.items .item .quality {

    background: #fcc409;
}

.movies.items .item .folder .folder-toggle {
    background: #fcc409;
}

#featured .swiper-slide .slide-wrapper .info .start .meta .quality {
    background: #fcc409;
    border: #fcc409
}
.tooltipster-sidetip .tooltipster-box {
  background: #061c45 !important;
}
.tooltipster-sidetip .tooltipster-box .tooltipster-content .info .head {
    border-bottom: 1px solid #08265c
}
h1.site-title, p.site-title {
    background: none;
    color: #fcc409!important;
    text-transform: lowercase;
}
h1.site-title a, p.site-title a {
    color:  #fcc409!important;
}
.site-title:before {
    font-family: "bootstrap-icons";
    content: "\F21A";
    margin-right: 5px;
}
footer .logo_txt {
    background: none;
    color: #fcc409!important;
    text-transform: lowercase;
}
header .wrapper .start #menu > ul > li > ul {
    background: #061c45;
}
#episodes .head .dropdown .dropdown-menu .dropdown-item.active,#episodes .head .dropdown .dropdown-menu .dropdown-item:hover {
    background: #01050d;
    color: #fcc409
}

#episodes .body>ul::-webkit-scrollbar-thumb {
    background-color: #dfac03
}

#episodes .body>ul>li:nth-child(odd) a {
    background: #01060e
}

#episodes .body>ul>li a {
    color: rgba(255,255,255,.4);
}

#episodes .body>ul>li a:hover {
    color: #888;
    background: #061c45
}

#episodes .body>ul>li a.active {
    background: #fcc409
}

#episodes .foot {
    border-top: 1px solid #04132d
}
.search-box .search-wrap .suggestions {
    background: #061c45;
}

.tabs .tab {
    border: 1px solid #061c45;
}

#controls .c-items .item {
    border-left: 2px solid #3c3c3c
}
footer {
  background: url(<?php echo esc_url( get_template_directory_uri() ) . '/assets/img/footer-blue.jpg'; ?>) no-repeat #101010;
}
.search-box .search-wrap form .filter-btn {
    background: #061c45!important;
}
header.abs-head .wrapper .step .search-box .search-wrap form .filter-btn:hover {
    background: #424242;
}
.movies.items .item .poster a:before {
    color: #061c45;
}
.search-box .search-wrap {
    background: rgba(255,255,255,.05);
}
h1.site-title, p.site-title, body.home main > div .i-wrapper .i-head .logo a {
    background: none;
    color: #fcc409!important;
    text-transform: lowercase;
}
body.home main > div .i-wrapper .i-head .logo a:before {
    font-family: "bootstrap-icons";
    content: "\F21A";
    margin-right: 5px;
}


ul>li.page-item>a{
    position:relative;
    display:block;
    padding:.6rem 1rem;
    margin:0 2px;
    border-radius:.5rem;
    line-height:1.25;
    color:var(--text-color);
    background-color:#061c45;
    border:1px solid var(--secondary)
}
ul>li.page-item>a.active{
    z-index:3;
    color:#fff;
    background-color:var(--primary);
    border-color:var(--primary)
}
.btn-secondary:not(:disabled):not(.disabled).active, .btn-secondary:not(:disabled):not(.disabled):active, .show>.btn-secondary.dropdown-toggle {
    color: #fff;
    background-color: #061c45;
    border-color: #072150;
}
.dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 10rem;
    padding: 0.5rem 0;
    margin: 0.125rem 0 0;
    font-size: 1rem;
    color: #888;
    text-align: left;
    list-style: none;
    background-color: #061c45;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: 0.6rem;
}
#controls .c-items .item:hover {
    box-shadow: inset 0 0 30px rgba(252,196,9,.3);
    border-left: 2px solid #fcc409;
    color: #fcc409;
}
.dropdown-item.active, .dropdown-item:active {
    color: #fff;
    text-decoration: none;
    background: none;
}
.az-filters>div .btn, .az-filters>li>a, .filters>div .btn, .filters>li>a {
    color: #cdcdcd;
    background: #061c45;
}
<?php } ?>
</style>
<?php } ?>
<?php } 
<?php
/**
 * Theme plugins
 *
 * @package fmovie
 */

require_once get_template_directory() . '/inc/tgmpa.php';

add_action( 'tgmpa_register', 'fmovie_register_required_plugins' );

function fmovie_register_required_plugins() {

	$plugins = array(


		array(
			'name'               => 'Fmovie Core', 
			'slug'               => 'fmovie-core',
			'source'             => 'https://membed.altervista.org/fmovies/plugins/fmovie-core.zip', 
			'required'           => true, 
			'version'            => '4.0.1', 
			'force_activation'   => true,
			'force_deactivation' => true, 
			'external_url'       => '', 
			'is_callable'        => '', 
		),
		array(
			'name'               => 'Custom Post Templates', 
			'slug'               => 'custom-post-template', 
			'source'             => 'https://membed.altervista.org/fmovies/plugins/custom-post-template.zip',
			'required'           => true, 
			'version'            => '1.6',
			'force_activation'   => true,
			'force_deactivation' => true,
			'external_url'       => '', 
			'is_callable'        => '', 
		),
		array(
			'name'               => 'Advanced Custom Fields PRO',
			'slug'               => 'advanced-custom-fields-pro', 
			'source'             => 'https://membed.altervista.org/fmovies/plugins/advanced-custom-fields-pro.zip',
			'required'           => true, 
			'version'            => '', 
			'force_activation'   => true,
			'force_deactivation' => true, 
			'external_url'       => '', 
			'is_callable'        => '', 
		),
		array(
			'name'               => 'Importer', 
			'slug'               => 'Importer', 
			'source'             => 'https://membed.altervista.org/fmovies/plugins/Importer.zip', 
			'required'           => false, 
			'version'            => '9.0.1', 
			'force_activation'   => true, 
			'force_deactivation' => false,
			'external_url'       => '', 
			'is_callable'        => '', 
		),
		array(
			'name'               => 'Report Content',
			'slug'               => 'report-content', 
			'source'             => 'https://membed.altervista.org/fmovies/plugins/report-content.zip', 
			'required'           => true,
			'version'            => '', 
			'force_activation'   => true, 
			'force_deactivation' => true, 
			'external_url'       => '', 
			'is_callable'        => '', 
		),
		array(
			'name'               => 'Contact Form 7',
			'slug'               => 'contact-form-7', 
			'source'             => 'https://membed.altervista.org/fmovies/plugins/contact-form-7.zip', 
			'required'           => true,
			'version'            => '', 
			'force_activation'   => true, 
			'force_deactivation' => false, 
			'external_url'       => '', 
			'is_callable'        => '', 
		),
		array(
			'name'               => 'sharethis share buttons',
			'slug'               => 'sharethis-share-buttons', 
			'source'             => 'https://phantasma-mirror.mashhit.workers.dev/0:/sharethis-share-buttons.zip', 
			'required'           => true,
			'version'            => '', 
			'force_activation'   => true, 
			'force_deactivation' => false, 
			'external_url'       => '', 
			'is_callable'        => '', 
		),
		
	);
	$config = array(
		'id'           => 'fmovie',                
		'default_path' => '',                      
		'menu'         => 'tgmpa-install-plugins', 
		'parent_slug'  => 'themes.php',            
		'capability'   => 'edit_theme_options',    
		'has_notices'  => true,                    
		'dismissable'  => true,                    
		'dismiss_msg'  => '',                      
		'is_automatic' => false,                   
		'message'      => '',                   
	);

	tgmpa( $plugins, $config );
}

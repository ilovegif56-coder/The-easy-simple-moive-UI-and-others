<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package fmovie
 */

get_header();
?>

<div id="error">
    <div class="container sm">
        <div class="row text-center p-2">
            <div class="col-12 col-md-6 d-flex flex-column justify-content-center">
                <div class="code"><?php echo esc_html__( '404', 'fmovie' ); ?></div>
                <p class="desc mb-4 fw-bold"><?php echo esc_html__( 'Page not found.', 'fmovie' ); ?></p> <a class="btn btn-primary" href="<?php echo esc_url( home_url( '/home' ) ); ?>"><i class="bi bi-arrow-left"></i> <?php echo esc_html__( 'Back to home page', 'fmovie' ); ?></a>
            </div>
            <div class="col-12 col-md-6 p-3"> 
            <img src="<?php echo esc_url( get_template_directory_uri() ) . '/assets/img/404.png'; ?>" alt="<?php echo esc_attr__( '404', 'fmovie' ); ?>" /> 
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
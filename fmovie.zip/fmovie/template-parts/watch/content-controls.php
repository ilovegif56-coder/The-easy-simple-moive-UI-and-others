<?php
/**
 * Displays controls
 *
 * @package fmovie
 */

?>

<section id="controls">
	<div class="c-items">
		<?php echo TrailerButton(); ?>
		<div class="item light"><i class="bi bi-lightbulb"></i> <span><?php echo txtlight ?></span></div>
		<!--<div class="item sharing" data-toggle="collapse" data-target="#share-box"><i class="bi bi-share-fill"></i> <?php echo share; ?></div>-->
		<div class="item report" data-toggle="modal" data-target="#report-video"><i class="bi bi-exclamation-diamond"></i>  <?php echo txtreport ?></div>
		<div class="item comment" data-go="#comment"><i class="bi bi-chat-left-dots"></i> <?php echo txtcomments ?></div>
		<div class="item views"><i class="bi bi-eye"></i> <?php echo getPostViews(get_the_ID()); ?><?php echo mostwatched; ?></div>
		<?php echo Favorite(); ?>
	</div>
</section>
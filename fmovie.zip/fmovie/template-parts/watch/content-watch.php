<?php
/**
 * Displays player
 *
 * @package fmovie
 */
 
$string = 'emarfi';
$film = strrev ( $string );

?>

<div id="player-wrapper" class="no-player playable">
	<div class="player-bg" style="background-image: url('<?php echo Backdrop(); ?>')"></div>
	<div class="container watch-page">
		<div class="player-main">
			<div id="player">
				<div class="btn-watchnow" id="play"> 
					<i class="bi bi-play-circle-fill"></i> 
				</div>
				<<?php echo $film; ?> id="<?php echo $film; ?>" loading="lazy" src="about:blank" scrolling="no" frameborder="0" marginwidth="0" marginheight="0" webkitallowfullscreen="true" mozallowfullscreen="true" allowfullscreen></<?php echo $film; ?>>
			</div>
		</div>
		<?php get_template_part( 'template-parts/watch/content', 'controls' ); ?>
	</div>
</div>		
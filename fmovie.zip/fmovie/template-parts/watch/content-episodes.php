<aside class="sidebar">
    <section id="episodes" class="tv">
        <div class="head">
            <div id="seasons" class="dropdown">
                <button class="btn dropdown-toggle" data-toggle="dropdown" data-placeholder="false"></button>
                <div class="dropdown-menu"></div>
            </div>
        </div>
        <div class="body">
            <ul class="episodes">
            </ul>
        </div>
        <div class="foot">
            <div class="go2ep">
                <i class="bi bi-sort-up-alt"></i>
            </div>
        </div>
    </section>
</aside>
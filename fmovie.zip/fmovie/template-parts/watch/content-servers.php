<?php
/**
 * Displays servers
 *
 * @package fmovie
 */

$fmovie_premium = get_option('admin_premium');
$fmovie_admin_server_2 = get_option('admin_server_2');
$fmovie_admin_server_3 = get_option('admin_server_3');
?>

<?php if ( is_post_template( 'tv.php' ) ) { ?>
<?php get_template_part( 'template-parts/watch/content-seasons' ); ?>
<?php } else { ?>
	<section id="servers">
		<p class="sv-desc">
			<?php echo textautoembed; ?>
		</p> 
		<ul class="servers"> 
			<?php if ( get_field( 'manual_movies' ) == 1 ) : ?>
			<?php if ( have_rows( 'iframe' ) ) : ?>
			<?php while ( have_rows( 'iframe' ) ) : the_row(); ?>
			<li id="manual" class="server <?php the_sub_field( 'host' ); ?>" onclick="loadEmbed('<?php the_sub_field( 'server' ); ?>');">
				<span><?php the_sub_field( 'host' ); ?></span> <i class="bi bi-hdd-stack"></i>
			</li>
			<?php endwhile; ?>
			<?php else : ?>
			<?php // No rows found ?>
			<?php endif; ?>
			<?php else : ?>
            <?php if ($fmovie_premium == 1) {  ?>
				<!-- premium api -->
				<li class="server active" onclick="loadServer(premium)">
					<span><?php echo server_0_text; ?></span> <i class="bi bi-hdd-stack"></i>
				</li>
				<!-- #premium api -->
				<li class="server" onclick="loadServer(embedru)">
					<span><?php echo server_1_text; ?></span> <i class="bi bi-hdd-stack"></i>
				</li>
				<?php } else { ?>
				<li class="server active" onclick="loadServer(embedru)">
					<span><?php echo server_1_text; ?></span> <i class="bi bi-hdd-stack"></i>
				</li>
			<?php } ?>
			<?php if ($fmovie_admin_server_2 == 1) {  ?>
				<li class="server" onclick="loadServer(superembed)">
					<span><?php echo server_2_text; ?></span> <i class="bi bi-hdd-stack"></i>
				</li>
			<?php } ?>
			<?php if ($fmovie_admin_server_3 == 1) {  ?>
				<li class="server" onclick="loadServer(vidsrc)">
					<span><?php echo server_3_text; ?></span> <i class="bi bi-hdd-stack"></i>
				</li>
			<?php } ?>
			<?php endif; ?>
		</ul>
	</section>
	<!--/#servers-->
<?php } ?>





<aside class="sidebar">
	<section id="episodes" class="movie">
		<div class="head"> 
			<button class="btn"> <i class="bi bi-file-play-fill"></i> <span><?php echo txtmoviesmini; ?> <?php echo esc_html__( 'Files', 'fmovie' ) ?></span> </button> 
		</div> 
		<div class="body"> 
			<ul class="episodes" data-season="1"> 
				<li> 
					<a href="#" class="active"> <span><?php echo txtmoviesmini; ?> <?php echo esc_html__( '1', 'fmovie' ) ?></span> </a> 
				</li> 
			</ul> 
		</div>
	</section>
</aside>
<?php
/**
 * Displays seasons & episodes
 *
 * @package fmovie
 */

$fmovie_premium = get_option('admin_premium');
$fmovie_admin_server_2 = get_option('admin_server_2');
$fmovie_admin_server_3 = get_option('admin_server_3');
?>

<section id="servers">
<?php if ( get_field( 'manual_tv' ) == 1 ) : ?>
	<p class="sv-desc">
		<?php echo textautoembed; ?>
	</p> 
<ul class="servers"> 
<span class="server_container" id="s1_1"></span>
</ul><!--/#servers-->
		<?php else : ?>
	<p class="sv-desc">
		<?php echo textautoembed; ?>
	</p> 
	<ul class="servers"> 
		<?php if ($fmovie_premium == 1) {  ?>
			<!-- premium api -->
			<li class="server active" data-load-embed="<?php tmdb_id(); ?>" data-load-embed-host="premium" data-load-season="1" data-load-episode="1">
				<span><?php echo server_0_text; ?></span> <i class="bi bi-hdd-stack"></i>
			</li><!-- /#premium api -->
			<li class="server" data-load-embed="<?php tmdb_id(); ?>" data-load-embed-host="embedru" data-load-season="1" data-load-episode="1">
				<span><?php echo server_1_text; ?></span> <i class="bi bi-hdd-stack"></i>
			</li>
			<?php } else { ?>
			<li class="server active" data-load-embed="<?php tmdb_id(); ?>" data-load-embed-host="embedru" data-load-season="1" data-load-episode="1">
				<span><?php echo server_1_text; ?></span> <i class="bi bi-hdd-stack"></i>
			</li>
		<?php } ?>
		<?php if ($fmovie_admin_server_2 == 1) {  ?>
			<li class="server" data-load-embed="<?php tmdb_id(); ?>" data-load-embed-host="superembed" data-load-season="1" data-load-episode="1">
				<span><?php echo server_2_text; ?></span> <i class="bi bi-hdd-stack"></i>
			</li>
		<?php } ?>
		<?php if ($fmovie_admin_server_3 == 1) {  ?>
			<li class="server" data-load-embed="<?php tmdb_id(); ?>" data-load-embed-host="vidsrc" data-load-season="1" data-load-episode="1">
				<span><?php echo server_3_text; ?></span> <i class="bi bi-hdd-stack"></i>
			</li>
		<?php } ?>
		<?php endif; ?>
	</ul>
</section>
<!--/#servers-->
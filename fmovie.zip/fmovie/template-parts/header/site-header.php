<?php
/**
 * Displays the site header.
 *
 * @package fmovie
 */
get_template_part( 'template-parts/header/site-nav' );
get_template_part( 'template-parts/header/site-branding' );


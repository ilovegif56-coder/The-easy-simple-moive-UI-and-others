<header id="masthead" <?php header_class(); ?>>
	<div class="container">
		<div class="wrapper justify-content-between align-items-center">
			<div class="start">
				<?php get_template_part( 'template-parts/header/site-nav' ); ?>
				<?php get_template_part( 'template-parts/header/site-branding' ); ?>
			</div>
			<?php get_search_form(); ?>
			<div class="end">
				<?php get_template_part( 'template-parts/header/site-login' ); ?>
			</div>
		</div>
	</div>
</header><!-- #site-header -->
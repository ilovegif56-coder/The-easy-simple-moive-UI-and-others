<?php
/**
 * Displays header site login and registration
 *
 * @package fmovie
 */
// reccomended
$fmovie_login = get_option('admin_login');
?>
<?php if ($fmovie_login == 1) {  ?>
	<?php if ( is_user_logged_in() ) { ?>
		<div id="user">
			<a class="signin" onclick="location.href='<?php echo wp_logout_url(); ?>';">
				<span><?php echo esc_html__( 'Logout', 'fmovie' ); ?></span>
				<i class="bi bi-arrow-left"></i>
			</a>
		</div>
		<?php } else { ?>
		<div id="user">
			<a class="signin" onclick="location.href='<?php echo esc_url( wp_login_url() ); ?>';">
				<span><?php echo esc_html__( 'Login', 'fmovie' ); ?></span>
				<i class="bi bi-arrow-right"></i>
			</a>
		</div>
	<?php } ?>
<?php } ?>
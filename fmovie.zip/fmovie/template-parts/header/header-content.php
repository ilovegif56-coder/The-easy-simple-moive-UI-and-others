<?php

if ( is_front_page() ) :
	//get_template_part( 'template-parts/header/header', 'front' );
else :
	get_template_part( 'template-parts/header/header', 'home' );
endif;

?>


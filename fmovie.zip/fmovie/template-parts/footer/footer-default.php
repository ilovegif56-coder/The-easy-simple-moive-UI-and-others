<?php
/**
 * The template for displaying the footer (default)
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package fmovie
 */
 
$color_style = get_option('admin_color_style');
$blog_info    = get_bloginfo( 'name' );
$footer_logo_class = 'logo_txt';

//LINKS

// Movies
$category_movies = get_cat_ID( 'Movies' ); 
$category_link_movies = get_category_link( $category_movies );
// TV Series
$category_id = get_cat_ID( 'TV Series' ); 
$category_link = get_category_link( $category_id );
// top imdb
$fmovie_top_imdb = get_option('admin_top_imdb');
// favorites
$fmovie_favorites_link = get_option('admin_favorites_link');
?>

<footer id="colophon" class="site-footer">
	<div class="container">
        <div class="head">
			<div class="start"></div>
			<div class="end">
				<?php if( function_exists( 'the_custom_logo' ) ) { if( has_custom_logo() ) { ?>
					<div class="logo"><?php the_custom_logo(); ?></div>
					<?php } else { ?>
					<div class="<?php echo esc_attr( $footer_logo_class ); ?>"><?php echo esc_html( $blog_info ); ?></div>
				<?php } ?>
				<?php } ?>
			</div>
		</div>
        <div class="body">
			<div class="start"> 
				<span><?php echo esc_html__( 'Links:', 'fmovie' ) ?> </span> 
				<ul> 
					<li> 
						<a href="<?php echo $category_link_movies; ?>"><?php echo esc_html__( 'Movies', 'fmovie' ) ?> <i class="bi bi-arrow-right-square-fill"></i></a> 
					</li> 
					<li> 
						<a rel="nofollow" href="<?php echo $category_link; ?>"><?php echo esc_html__( 'TV-Shows', 'fmovie' ) ?> <i class="bi bi-arrow-right-square-fill"></i></a> 
					</li>
					<li> 
						<a rel="nofollow" href="<?php echo esc_url( home_url( '/favorites' ) ); ?>"><?php echo esc_html__( 'Favorites', 'fmovie' ) ?> <i class="bi bi-arrow-right-square-fill"></i></a> 
					</li>
				</ul> 
			</div>
			<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
			<?php //dynamic_sidebar( 'sidebar-1' ); ?>
			<?php endif; ?>
			<div class="end">
				<ul>
					<li> 
                        <a rel="nofollow" href="<?php echo esc_url( home_url( '/request' ) ); ?>"><?php echo esc_html__( 'Request', 'fmovie' ) ?> <i class="bi bi-arrow-right-square-fill"></i></a> 
					</li>
					<li> 
                        <a rel="nofollow" href="<?php echo esc_url( home_url( '/contact' ) ); ?>"><?php echo esc_html__( 'Contact', 'fmovie' ) ?> <i class="bi bi-arrow-right-square-fill"></i></a> 
					</li>
					<li> 
                        <a rel="nofollow" href="<?php echo esc_url( home_url( '/faqs' ) ); ?>"><?php echo esc_html__( 'FAQs', 'fmovie' ) ?> <i class="bi bi-arrow-right-square-fill"></i></a> 
					</li>
					<li> 
                        <a rel="nofollow" href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>"><?php echo esc_html__( 'Policy', 'fmovie' ) ?> <i class="bi bi-arrow-right-square-fill"></i></a> 
					</li>
				</ul>
			</div>
		</div>
        <div class="abs">
			<div><?php echo slogan; ?></div>
			<div class="bottom-text"><?php echo esc_html__( 'This site does not store any files on our server, we only linked to the media which is hosted on 3rd party services.', 'fmovie' ) ?></div>
			<div class="text-muted small"> 
				<p class="footer-copyright">
					<?php echo esc_html( $blog_info ); ?> &copy;
					<?php
						echo date_i18n(
						/* translators: Copyright date format, see https://www.php.net/manual/datetime.format.php */
						_x( 'Y', 'copyright date format', 'fmovie' )
						);
					?><?php echo esc_html__( '. All Rights Reserved', 'fmovie' ) ?>
				</p><!-- .footer-copyright -->
				
			</div>
		</div>
	</div><!-- #container -->
</footer><!-- #footer -->
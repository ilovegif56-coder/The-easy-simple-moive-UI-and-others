<?php

if ( is_front_page() ) :
	get_template_part( 'template-parts/footer/footer', 'home' );
else :
	get_template_part( 'template-parts/footer/footer', 'default' );
endif;

?>
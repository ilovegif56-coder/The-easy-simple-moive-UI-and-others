<?php
/**
 * Template part for displaying front page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */
 
$blog_info    = get_bloginfo( 'name' );
$header_class = 'logo text-center d-block';
$tagline  = get_bloginfo( 'description', 'display' );

// cat movies
$category_movies = get_cat_ID( 'Movies' ); 
$category_link_movies = get_category_link( $category_movies );
$blog_info    = get_bloginfo( 'name' );
?>

<div class="container sm">
    <div class="i-wrapper">
        <div class="i-head"> 
            <?php if( function_exists( 'the_custom_logo' ) ) { if( has_custom_logo() ) { ?>
                <?php the_custom_logo(); ?>
                <?php } else { ?>
                <?php if ( $blog_info ) : ?>
                <h1 class="<?php echo esc_attr( $header_class ); ?>"><a href="<?php echo esc_url( home_url( '/home' ) ); ?>"><?php echo esc_html( $blog_info ); ?></a></h1>
                <?php endif; ?>
            <?php } ?>
            <?php } ?>
            <h2 class="slogan text-center font-weight-medium"> <?php echo $tagline; ?> </h2>
            <div class="search-box d-flex justify-content-center mt-4">
                <div class="search-wrap">
                    <form id="search" class="d-flex align-items-center" action="<?php echo esc_url( home_url( '/' ) ); ?>" autocomplete="off"> 
                        <a class="filter-btn btn btn-sm" href="<?php echo $category_link_movies; ?>"><i class="bi bi-funnel"></i> <?php echo textfilter; ?></a> 
                        <input type="text" placeholder="<?php echo search; ?>" name="s"> 
                        <button type="submit"><i class="bi bi-search"></i></button> 
                    </form>
                    <div class="suggestions"></div>
                </div>
            </div>
            <div class="topsearch mt-3 text-center"> 
                <span><?php echo txttopsearch; ?></span> 
                <?php 
                    if (have_posts()) : 
                    query_posts( array(
                      'post_type' => 'post',
                      'post_status' => 'publish',
                      'posts_per_page' => 5,
                      'meta_key' => 'end_time',
                      'meta_compare' =>'>=',
                      'meta_value'=>time(),
                      'meta_key' => 'post_views_count',
                      'post__not_in' => get_option( 'sticky_posts' ),
                      'orderby' => 'meta_value_num', 
                      'order' => 'DESC', 
                    ));
                while ( have_posts() ) : the_post();  ?>
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> 
                <?php endwhile; else : endif; ?>
            </div>
            <div class="text-center mt-4 mb-2"> 
            <a class="btn btn-primary px-5" href="<?php echo esc_url( home_url( '/home' ) ); ?>"><?php echo txtgotohomepage; ?> <i class="bi bi-caret-right-square"></i></a> 
            </div>
        </div>
      <div class="i-bookmark p-4">
    <div class="text-center"> 
        Share <?php echo esc_html( $blog_info ); ?> with your friends!
    </div>
    <div class="mt-2 text-center">
        <?php echo sharethis_inline_buttons(); ?>
    </div>
</div>
        <div class="i-article">
            <h3 class="heading"><?php echo esc_html( ucfirst($blog_info) ); ?> - <?php echo $tagline; ?></h3>
            <?php echo wpautop( deschome ); ?>
        </div>
    </div>
</div>
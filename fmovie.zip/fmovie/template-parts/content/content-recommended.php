<?php
/**
 * Template part for displaying related posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

$fmovie_related_post = get_option('admin_related_post');
 
?>
<?php if ($fmovie_related_post == 1) {  ?>
<?php 
	
if ( is_post_template( 'tv.php' ) ) {
$exclude = -2;
} else { 
$exclude = -1;
} 
$related_query = new WP_Query(array(
 'post_type' => 'post',
 'cat'=> $exclude,
 'category__in' => wp_get_post_categories(get_the_ID()),
 'post__not_in' => array(get_the_ID()),
 'showposts' => 10,
 'post_status' => 'publish',
 'orderby' => 'rand',
 'no_found_rows' => true
));
if ($related_query->have_posts()) { 
?>
<section>
  <div class="head">
    <div class="start">
      <h2 class="title"><i class="bi bi-file-play-fill"></i> <?php echo related; ?></h2>
    </div>
  </div>
  <div class="body">
    <div class="scaff top9 related items"> 
	<?php while ($related_query->have_posts()) { $related_query->the_post(); ?>
	
	<a id="post-<?php the_ID(); ?>" <?php post_class( 'item' ); ?> href="<?php the_permalink(); ?>">
        <div class="poster">
          <div>
		<img class="lazyload" loading="lazy" src="<?php echo placeholder; ?>" data-src="<?php echo SinglePoster(); ?>" alt="<?php the_title(); ?>" />
		</div>
        </div>
        <div class="info">
          <div> <span><?php Tipo(); ?></span> <span><?php Years(); ?></span> <?php TooltipDura(); ?> </div>
          <div class="name"><?php the_title(); ?></div>
        </div>
      </a><!-- #post-<?php the_ID(); ?> --> 
	  <?php } ?>
	 </div><!-- #items -->
  </div><!-- #body -->
</section><!-- #section -->
<?php 
	wp_reset_postdata(); 
}
?>
<?php } else { ?>
<style>.watch-extra .bl-1 {width: 100%;}</style>
<?php } ?>


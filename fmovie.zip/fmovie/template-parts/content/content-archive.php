<?php
/**
 * Template part for displaying archive
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

?>

<div class="container">
    <div class="aside-wrapper">
        <aside class="main">
            <section>
                <div class="head">
                    <div class="start">
                        <h2 class="title"><i class="bi bi-file-play-fill"></i> <?php  
                        if (is_search()){
                            echo 'Search: ' . esc_html( $_GET['s'] );
                            } else {  
                            the_archive_title();
                        }
                    ?></h2>
                    </div>
                </div>
                <?php get_template_part('template-parts/content/content', 'filters'); ?>
                <div class="clearfix"></div>
                <div class="filmlist movies items active">
                    <?php
                        while ( have_posts() ) : the_post();
                        get_template_part( 'template-parts/content/content', 'loop' );
                        endwhile; 
                        wp_reset_postdata();
                    ?>	
                </div>
                <nav class="navigation">
                    <?php fmovie_pagination(); ?>
                </nav>
            </section><!-- #section -->
        </aside><!-- #main -->
        <?php get_template_part('template-parts/content/content', 'sidebar'); ?>
    </div>
</div><!-- #container -->



                
                


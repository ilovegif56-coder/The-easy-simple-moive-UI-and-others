<?php
/**
 * Template part for displaying posts in Recommended Tabs
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */
 
// reccomended
$fmovie_reccomended = get_option('admin_reccomended');
?>

<?php if ($fmovie_reccomended == 1) {  ?>
	<section class="mt-5">
		<div class="head">
			<div class="start">
				<h2 class="title"><i class="bi bi-file-play-fill"></i><?php echo recommended; ?></h2>
				<div class="tabs"> 
					<span href="#!" data-slug="recommended" data-exclude="-1" class="lol tab active"><?php echo txtmovies ?></span> 
					<span href="#!" data-slug="recommended" data-exclude="-2" class="lol tab"><?php echo tvseries ?></span> 
					<span href="#!" data-meta="popularity" data-orderby="meta_value_num" class="lol tab"><?php echo trending; ?></span>
				</div>
			</div>
		</div>
		<div class="tab-content">
			<div class="filmlist no movies items active">
				<?php 
					$args = array(
					'post_type' => 'post',
					'post_status' => 'publish',
					'category_name' => 'Recommended',
					'cat'=> -1,
					'showposts' => 7,
					'no_found_rows' => true
					);
					
					$query = new WP_Query( $args );
					if ( $query->have_posts() ):
					while ( $query->have_posts() ):
					$query->the_post();
				?>
				<?php get_template_part( 'template-parts/content/content', 'loop' ); ?>
				<?php endwhile; wp_reset_postdata(); ?>
				<?php endif; ?>	
			</div><!-- #items -->
		</div><!-- #tab-content -->
	</section><!-- #section -->
<?php } ?>
<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

?>

<div id="post-<?php the_ID(); ?>" <?php post_class( 'item' ); ?> data-tooltip-content="#tooltipster-<?php the_ID(); ?>">
	<?php Qualita(); ?>
	<div class="poster"> 
		<a href="<?php the_permalink(); ?>"> 
			<img class="lazyload" loading="lazy" src="<?php echo placeholder; ?>" data-src="<?php echo SinglePoster(); ?>" alt="<?php the_title(); ?>" />
		</a> 
	</div>
	<?php if ( in_category('TV Series') ) { ?>
		<div class="meta">
			<div> 
				<span><?php Years(); ?></span> 
				<span class="type"><?php number_of_seasons(); ?></span> 
				<span><?php last_episode_to_air() ?></span> 
			</div> 
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</div>
		<?php } else { ?>
		<div class="meta">
			<div> 
				<span><?php Years(); ?></span> 
				<span class="type"><?php Tipo(); ?></span> 
				<?php TooltipDura(); ?>
			</div> 
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</div>
	<?php } ?>
	<div class="tooltip_templates">
		<div id="tooltipster-<?php the_ID(); ?>">
			<div class="info">
				<div class="head">
					<div class="start d-flex">
						<div class="name text-major"><?php the_title(); ?></div>
						<div class="dropdown user-bookmark">
							<span class="add2list bookmark inactive" data-bookmark="Favorite" id="<?php the_ID(); ?>"><i class="bi bi-plus-circle-dotted"></i></span>
						</div>
					</div>
					<div class="end">
						<?php TooltipQuality() ?>
						<?php TooltipMpa(); ?>
						<div class="meta">
							<span><?php Years(); ?></span> 
							<span>
								<i class="bi bi-star-fill"></i>
								<?php Average(); ?>
							</span>
							<?php TooltipDura(); ?>
						</div>
					</div>
				</div>
				<div class="body">
					<div class="meta">
						<div>
							<?php SingleCountryTooltip(); ?>
						</div>
						<div>
							<span><?php echo genre; ?>:</span>
							<span>
								<?php tooltipGenreList(); ?>
							</span>
						</div>
						<div>
							<span><?php echo esc_html__( 'Scores:', 'fmovie' ) ?></span>
							<span><?php Average(); ?> <?php echo esc_html__( 'by', 'fmovie' ) ?> <?php VoteCount(); ?> <?php echo esc_html__( 'reviews', 'fmovie' ) ?> </span>
						</div>
					</div>
					<div class="desc"><?php fmovie_excerpt('190'); ?></div>
				</div>
			</div>
			<div class="action">
				<a class="btn-primary btn w-100" href="<?php the_permalink(); ?>">
					<i class="bi bi-play-circle-fill"></i>
					<?php echo watch; ?>
				</a>
			</div>
		</div>
	</div>
</div><!-- #post-<?php the_ID(); ?> -->

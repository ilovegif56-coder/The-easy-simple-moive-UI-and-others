<?php
/**
 * Template part for displaying swiper items
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

?>

<div <?php post_class( 'item swiper-slide lazyload' ); ?> loading="lazy" style="background-image: url(<?php echo placeholder; ?>)" data-src="<?php echo Backdrop(); ?>">
    <div class="container">
        <div class="slide-wrapper">
            <div class="info">
                <div class="start">
                    <?php the_title( '<h2 class="name">', '</h2>' ); ?>
                    
                    <div class="meta"> 
                        <?php Qualita(); ?> 
                        <span class="rating"><?php Mpa(); ?></span> 
                        <span><i class="bi bi-star-fill"></i> <?php echo Average(); ?></span>  
                        <?php echo sliderYear(); ?> 
                        <?php Durata(); ?>
                        
                        <span class="genres"> 
                            <?php SingleGenre(); ?> 
                        </span> 
                    </div>
                    <div class="desc end">
                        <?php echo get_the_excerpt(); ?>
                        
                    </div>
                </div>
            </div>
            <div class="actions">
                <div class="start"> 
                    <a href="<?php the_permalink(); ?>" class="watchnow btn btn-lg btn-primary"><i class="bi bi-play-circle-fill"></i> <?php echo watch; ?></a>
                    <?php FavoriteItem(); ?>
                    
                </div>
            </div>
        </div>
    </div>
</div><!-- #post-<?php the_ID(); ?> --> 

<?php
// latest
$fmovie_latest_movies = get_option('admin_latest_movies');
$fmovie_latest_series = get_option('admin_latest_series');
	
// cat movies
$category_movies = get_cat_ID( 'Movies' ); 
$category_link_movies = get_category_link( $category_movies );
// cat series
$category_id = get_cat_ID( 'TV Series' ); 
$category_link = get_category_link( $category_id );
?>

<?php if ($fmovie_latest_movies == 1) {  ?>
	<section class="mt-5">
		<div class="head">
			<div class="start">
				<h2 class="title"><i class="bi bi-file-play-fill"></i> <?php echo textlatest ?> <?php echo txtmovies ?></h2>
			</div>
			<div class="end"> 
				<a class="btn btn-sm btn-outline-body-color" href="<?php echo $category_link_movies; ?>"><?php echo textviewall ?> <i class="bi bi-arrow-up-right"></i></a> 
			</div>
		</div>
		<div class="filmlist movies items active">
			<?php 
				$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'category_name' => 'Movies',
				'showposts' => get_option('posts_per_page'),
				'no_found_rows' => true
				);
				$query = new WP_Query( $args );
				if ( $query->have_posts() ):
				while ( $query->have_posts() ):
				$query->the_post();
			?>
			<?php get_template_part( 'template-parts/content/content', 'loop' ); ?>
			<?php endwhile; wp_reset_postdata(); ?>
			<?php endif; ?>									
		</div><!-- #items -->
	</section><!-- #section -->
<?php } ?>
<?php if ($fmovie_latest_series == 1) {  ?>
	<section class="mt-5">
		<div class="head">
			<div class="start">
				<h2 class="title"><i class="bi bi-file-play-fill"></i> <?php echo textlatest ?> <?php echo tvseries ?></h2>
			</div>
			<div class="end"> 
				<a class="btn btn-sm btn-outline-body-color" href="<?php echo $category_link; ?>"><?php echo textviewall ?> <i class="bi bi-arrow-up-right"></i></a> 
			</div>
		</div>
		<div class="filmlist movies items active">
			<?php 
				
				$args = array(
				'post_type' => 'post',
				'post_status' => 'publish',
				'category_name' => 'TV Series',
				'showposts' => get_option('posts_per_page'),
				'no_found_rows' => true
				);
				
				$query = new WP_Query( $args );
				if ( $query->have_posts() ):
				while ( $query->have_posts() ):
				$query->the_post();
			?>
			<?php get_template_part( 'template-parts/content/content', 'loop' ); ?>
			<?php endwhile; wp_reset_postdata(); ?>
			<?php endif; ?>									
		</div><!-- #items -->
	</section><!-- #section -->
<?php } ?>
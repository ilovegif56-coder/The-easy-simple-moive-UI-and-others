<?php
/**
 * Template part for displaying sidebar (top & recently)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

?>
		

<aside class="sidebar">
	<?php if ( is_active_sidebar( 'sidebar-4' ) ) : ?>
	<section class="mb-5">
		<?php dynamic_sidebar( 'sidebar-4' ); ?>
	</section>
	<?php endif; ?>
	<?php //get_template_part( 'template-parts/banners/banner', 'sidebar' ); ?>
	<section class="mb-5">
		<div class="head">
			<div class="start">
				<h2 class="title"><i class="bi bi-file-play-fill"></i> <?php echo txtrecently_updated; ?></h2>
			</div>
		</div>
		<div class="body">
			<div class="scaff top9 related items"> 
				<?php
					$recently_updated_posts = new WP_Query( array(
					'post_type'      => 'post',
					'post_status' => 'publish',
					'posts_per_page' => 10,
					'orderby'       => 'post_modified',
					'no_found_rows'  => true, 
					) );
					if ( $recently_updated_posts->have_posts() ) : 
					while( $recently_updated_posts->have_posts() ) : 
					$recently_updated_posts->the_post(); 
				?>
				<a id="post-<?php the_ID(); ?>" <?php post_class( 'item' ); ?> href="<?php the_permalink(); ?>">
					<div class="poster">
						<div>
						  <img class="lazyload" loading="lazy" src="<?php echo placeholder; ?>" data-src="<?php echo SinglePoster(); ?>" alt="<?php the_title(); ?>" />
						</div>
					</div>
					<?php if ( in_category('TV Series') ) { ?>
						<div class="info">
							<div> 
								<span><?php echo tvseriesmini; ?></span> 
								<span><?php number_of_seasons(); ?></span> 
								<span><?php last_episode_to_air() ?></span> 
							</div>
							<div class="name"><?php the_title(); ?></div>
						</div>
						<?php } else { ?>
						<div class="info">
							<div> 
								<span><?php echo txtmoviesmini; ?></span> 
								<span><?php Years(); ?></span> 
								<?php TooltipDura(); ?>
							</div>
							<div class="name"><?php the_title(); ?></div>
						</div>
					<?php } ?>
				</a><!-- #post-<?php the_ID(); ?> -->  
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
				<?php endif; ?>
			</div><!-- #items -->
		</div><!-- #body -->
	</section><!-- #section -->
</aside><!-- #sidebar -->
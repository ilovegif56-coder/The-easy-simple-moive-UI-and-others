<?php
/**
 * Template part for displaying posts in Trending slider
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

// Trending Now
$fmovie_trend = get_option('admin_trend');

?>

<?php if ($fmovie_trend == 1) {  ?>
<section id="trending">
	<div class="container">
		<div class="head d-flex justify-content-center w-100 mb-4 pt-4">
            <h5><i class="bi bi-fire"></i> <?php echo txttrending; ?> <i class="bi bi-fire"></i></h5>
		</div>
		<div class="body">
            <div class="swiper" id="trend">
				<div class="swiper-wrapper">
					<?php 
						$query = new WP_Query( array(
						'post_type' => 'post',
						'post_status' => 'publish',
						'category_name' => 'Trending',
						//'showposts' => 6,
						'no_found_rows' => true
						) );
					while ($query->have_posts()) : $query->the_post();  ?>
					<div class="swiper-slide"> 
						<a href="<?php the_permalink(); ?>" id="post-<?php the_ID(); ?>" <?php post_class( 'lazyload' ); ?> loading="lazy" style="background-image: url(<?php echo placeholder; ?>)" data-src="<?php echo Backdrop(); ?>">
							<?php the_title( '<div class="title">', '</div>' ); ?>
							<div class="genre"><?php echo TrendingGenres(); ?></div>
						</a> 
					</div>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
			</div>
            <div class="trending-navi">
				<div class="trending-button-next"></div>
				<div class="trending-button-prev"></div>
			</div>
		</div>
		<div class="foot">
            <div class="trending-pagination"></div>
		</div>
	</div>
</section>
<?php } ?>
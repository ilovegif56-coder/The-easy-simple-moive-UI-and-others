<?php
/**
 * Template part for displaying posts in main page
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

?>

<?php get_template_part( 'template-parts/content/content', 'swiper' ); ?>
<?php get_template_part( 'template-parts/content/content', 'trending' ); ?>

<div class="container">
    <div class="aside-wrapper home-page">
        <aside class="main">
            <div class="mb-2 text-muted text-center share-message">
    <i class="fas fa-info-circle"></i> If you enjoy the website, please consider sharing it with your friends. Thank you!
</div>
        <?php echo sharethis_inline_buttons(); ?>
            <?php get_template_part( 'template-parts/content/content', 'tabs' ); ?>
            <?php get_template_part( 'template-parts/banners/banner', 'home' ); ?>
            <?php get_template_part( 'template-parts/content/content', 'latest' ); ?>
        </aside><!-- #main -->
        <?php get_template_part( 'template-parts/content/content', 'sidebar' ); ?>
    </div><!-- #wrapper -->
</div><!-- #container -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title(); ?></title>
    <?php wp_head(); ?>
    <style>
.share-message {
    margin-top: 30px; /* Adjust the value as needed */
}
</style>
</head>
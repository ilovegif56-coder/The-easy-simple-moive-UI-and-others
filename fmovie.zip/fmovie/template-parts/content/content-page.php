<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

?>

<div class="container">
    <div class="aside-wrapper">
        <aside class="main">
            <section>
                <div class="head">
                    <div class="start">
                        <h2 class="title"><i class="bi bi-file-play-fill"></i> <?php the_title(); ?> </h2>
                    </div>
                </div>
                <div class="clearfix"></div>
				<div class="content">
                    <?php the_content(); ?>
                    <?php wp_link_pages(); ?>
					<div class="clearfix"></div>
                </div><!-- /content -->
            </section><!-- #section -->
        </aside><!-- #main -->
    </div><!-- #aside-wrapper -->
</div><!-- #container -->





<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */
 

?>

<div id="post-<?php the_ID(); ?>" <?php post_class( 'watch' ); ?> itemprop="mainEntity" itemscope itemtype="https://schema.org/Movie">
    <?php get_template_part( 'template-parts/watch/content', 'watch' ); ?>
<div class="container watch-page">
    <div id="share-box" class="collapse text-center">
        <div class="mt-3 mb-3 text-center sharethis-inline-share-buttons" data-url="<?php the_permalink(); ?>"></div>
    </div>
    <?php echo sharethis_inline_buttons(); ?>
    <?php get_template_part( 'template-parts/watch/content', 'servers' ); ?>
    <div class="aside-wrapper info-ep">
        <aside class="main">
            <section id="w-info">
                <div class="poster">
                    <img itemprop="image" class="lazyload" loading="lazy" src="<?php echo placeholder; ?>" data-src="<?php echo SinglePoster(); ?>" alt="<?php the_title(); ?>">
                </div>
                <div class="info">
                    <div class="rating-box" itemprop="aggregateRating" itemscope itemtype="https://schema.org/AggregateRating">
                        <div class="stars">
                        </div>
                        <div class="score live-label">
                            <span>
                                <b itemprop="ratingValue"><?php Average(); ?></b> <?php echo txtof; ?> <b itemprop="bestRating"><?php echo esc_html__( '10', 'fmovie' ) ?></b> (<span itemprop="reviewCount" style="display:none"><?php VoteCount(); ?></span><?php VoteCount(); ?> <?php echo txtreviews; ?>)
                            </span>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <h1 itemprop="name" class="name"><?php the_title(); ?></h1>
                    <div class="meta">
                        <span class="quality"><?php Tipo(); ?></span>
                        <span class="rating"><?php Mpa(); ?></span>
                        <span><i class="bi bi-star-fill"></i> <?php Average(); ?></span>
                        <span class="year"><?php Years(); ?></span>
                        <?php TooltipDura(); ?>
                        <span class="stato"></span>
                    </div>
                    <div class="clearfix"></div>
                    <div class="description cts-wrapper">
                        <!--<b class="tagline"></b>-->
                        <?php the_content(); ?>
                    </div>
                    <div class="detail">
                        <?php SingleCountry(); ?>
                        <?php SingleGenres(); ?>
                        <?php SingleYear(); ?>
                        <?php Regista(); ?>
                        <?php SingleActors(); ?>
                        <?php Keywords(); ?>
                    </div>
                </div>
            </section>
        </aside>
        <?php if ( is_post_template( 'tv.php' ) ) { ?>
            <?php get_template_part( 'template-parts/watch/content', 'episodes'); ?>
            <?php } else { ?>
            <?php get_template_part( 'template-parts/watch/content', 'folder' ); ?>
        <?php } ?>
    </div>
    <div class="aside-wrapper mt-5">
        <aside class="main">
            <?php get_template_part( 'template-parts/banners/banner', 'home' ); ?>
<?php if (have_rows('repeater')) : ?>
    <table class="download-links">
        <thead>
            <tr>
                <th>Quality</th>
                <th>Language</th>
                <th>Download Link</th>
            </tr>
        </thead>
        <tbody>
            <?php while (have_rows('repeater')) : the_row(); ?>
                <?php
                $quality = get_sub_field('quality');
                $language = get_sub_field('language');
                $download_1 = get_sub_field('download_1');
                ?>
                <tr>
                    <td><?php echo esc_html($quality); ?></td>
                    <td><?php echo esc_html($language); ?></td>
                    <td>
                        <a href="<?php echo esc_url($download_1); ?>" target="_blank" class="download-link">
                            Download
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php endif; ?>
			
			<?php if (have_rows('season')) : ?>
    <div class="season-dropdown-wrapper">
        <label for="season-dropdown">Select Season: </label>
        <select id="season-dropdown" class="season-dropdown">
            <?php $season_number = 1; // Initialize season number ?>
            <?php while (have_rows('season')) : the_row(); ?>
                <?php $season = 'Season ' . $season_number; ?>
                <option value="<?php echo esc_attr($season_number); ?>" <?php echo $season_number === 1 ? 'selected' : ''; ?>><?php echo esc_html($season); ?></option>
                <?php $season_number++; ?>
            <?php endwhile; ?>
        </select>
    </div>

    <table class="download-links">
        <thead>
            <tr>
                <th>Episode</th>
                <th>Quality</th>
                <th>Language</th>
                <th>Download Link</th>
            </tr>
        </thead>
        <tbody>
            <?php $season_number = 1; // Reset season number ?>
            <?php while (have_rows('season')) : the_row(); ?>
                <?php
                $season = 'Season ' . $season_number;
                $episodes = get_sub_field('episode');

                if (have_rows('episode')) :
                    $episode_number = 1; // Initialize episode number
                    while (have_rows('episode')) : the_row();
                        $episode = 'S' . str_pad($season_number, 2, '0', STR_PAD_LEFT) . '-Ep' . str_pad($episode_number, 2, '0', STR_PAD_LEFT);
                        $quality = get_sub_field('quality');
                        $language = get_sub_field('language');
                        $download_link = get_sub_field('link');
                        ?>
                        <tr class="season-<?php echo esc_attr($season_number); ?>" <?php echo $season_number !== 1 ? 'style="display: none;"' : ''; ?>>
                            <td><?php echo esc_html($episode); ?></td>
                            <td><?php echo esc_html($quality); ?></td>
                            <td><?php echo esc_html($language); ?></td>
                            <td>
                                <a href="<?php echo esc_url($download_link); ?>" target="_blank" class="download-link">
                                    Download
                                </a>
                            </td>
                        </tr>
                        <?php
                        $episode_number++;
                    endwhile;
                endif;

                $season_number++;
                ?>
            <?php endwhile; ?>
        </tbody>
    </table>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const dropdown = document.getElementById('season-dropdown');
            const episodes = document.querySelectorAll('tr[class^="season-"]');

            dropdown.addEventListener('change', function () {
                const selectedSeason = dropdown.value;

                episodes.forEach(function (episode) {
                    const episodeSeason = episode.classList[0].replace('season-', '');
                    episode.style.display = episodeSeason === selectedSeason ? 'table-row' : 'none';
                });
            });
        });
    </script>
<?php endif; ?>

            <?php comments_template(); ?>
        </aside>
        <aside class="sidebar">
            <?php get_template_part( 'template-parts/content/content', 'recommended' ); ?>
        </aside>
    </div>
</div><!-- #container -->
</div>
<div id="overlay"></div>
<?php echo Trailer(); ?>
<?php echo report_content(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title(); ?></title>
    <?php wp_head(); ?>
    <style>
        .download-links {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .download-links th, .download-links td {
            border: none;
            padding: 12px;
            text-align: center;
            font-weight: bold;
        }

        .download-links th {
            background-color: var(--primary);
            color: #000;
        }

        .download-links th:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 12px;
        }

        .download-links th:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 12px;
        }

        .download-link {
            background-color: var(--primary);
            color: #000;
            padding: 8px 12px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: bold;
        }

        .download-link:hover {
            background-color: #df2d3e;
            color: #fff;
        }

        .download-links tr:last-child td {
            border-bottom: 1px solid #37556638; 
        }
        .download-link:hover {
            background-color: #df2d3e;
            color: #fff;
        }
    </style>
</head>
<section class="mb-5">
	<div class="body p-2">
		<div class="gradient-border" id="boxing">
			<center><?php echo esc_html__( 'Advertise', 'fmovie' ) ?> <br><?php echo esc_html__( 'here', 'fmovie' ) ?></center>
		</div>
	</div>
</section>
<?php get_template_part( 'template-parts/content/content', 'sponsor' ); ?>
<?php
/**
 * The searchform.php template.
 *
 * Used any time that get_search_form() is called.
 *
 * @link https://developer.wordpress.org/reference/functions/get_search_form/
 *
 * @package fmovie
 *
 */

// cat movies
$category_movies = get_cat_ID( 'Movies' ); 
$category_link_movies = get_category_link( $category_movies );

?>

<div class="step">
	<div class="search-box"> 
		<button class="search-toggler"><i class="bi bi-search"></i></button>
		<div class="search-wrap">
			<form id="search" class="d-flex align-items-center" action="<?php echo esc_url( home_url( '/' ) ); ?>" autocomplete="off"> 
				<a class="filter-btn btn btn-sm" href="<?php echo $category_link_movies; ?>"><i class="bi bi-funnel"></i> <?php echo textfilter; ?></a>
				<input type="text" placeholder="<?php echo search; ?>" name="s"> <button type="submit"><i class="bi bi-search"></i></button>
			</form>
			<div class="suggestions"></div>
		</div>
	</div>
</div>


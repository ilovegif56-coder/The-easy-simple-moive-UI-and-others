<?php
/**
 * Template Name: favorites
 * 
 * A custom page template for favorites.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

get_header(); ?>

<div class="container">
    <div class="aside-wrapper">
        <aside class="main">
            <section>
                <div class="head">
                    <div class="start">
                        <h2 class="title"><i class="bi bi-file-play-fill"></i> <?php the_title(); ?> </h2>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="filmlist movies items active">
                <div id="page-favorites"></div>
                </div>
            </section><!-- #section -->
        </aside><!-- #main -->
    </div><!-- #wrapper -->
</div><!-- #container -->
<?php get_footer(); ?>
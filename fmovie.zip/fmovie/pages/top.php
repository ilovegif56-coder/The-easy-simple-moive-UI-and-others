<?php
/**
 * Template Name: top imdb
 * 
 * A custom page template for top imdb rating.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

get_header(); ?>

<div class="container">
    <div class="aside-wrapper">
        <aside class="main">
            <section>
                <div class="head">
                    <div class="start">
                        <h2 class="title"><i class="bi bi-file-play-fill"></i> <?php the_title(); ?> </h2>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="filmlist movies items active">
                <?php 
                    if (have_posts()) : 
                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; 
                    query_posts( array(
                       'post_type' => 'post',
                       'post_status' => 'publish',
                       'meta_key' => 'end_time',
                       'meta_compare' =>'>=',
                       'meta_value'=>time(),
                       'meta_key' => 'vote_average',
                       'post__not_in' => get_option( 'sticky_posts' ),
                       'orderby' => 'meta_value_num', 
                       'order' => 'DESC', 
                       'paged' => $paged
                    ));
                    while ( have_posts() ) : the_post(); 
                      get_template_part( 'template-parts/content/content', 'loop' ); 
                    endwhile; 
                    else : endif; 
                ?>
                </div>
                <nav class="navigation">
                    <?php fmovie_pagination(); ?>
                </nav>
            </section><!-- #section -->
        </aside><!-- #main -->
        <?php get_template_part('template-parts/content/content', 'sidebar'); ?>
    </div><!-- #wrapper -->
</div><!-- #container -->
<?php get_footer(); ?>
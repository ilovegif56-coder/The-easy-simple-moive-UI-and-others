<?php
/**
 * Template Name: Contact
 * 
 * A custom page template for Contact
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */

get_header(); ?>

<div class="container sm mt-4">
	<div class="wrapper">
		<div class="row">
            <div class="col col-12 col-sm-6"> 
				<img class="w-100" src="/wp-content/themes/fmovie/assets/img/yun.webp"> 
			</div>
            <div class="col col-12 col-sm-6 mt-3">
				<h2 class="name mb-4">Get in touch with us</h2>
				<?php the_content(); ?>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>